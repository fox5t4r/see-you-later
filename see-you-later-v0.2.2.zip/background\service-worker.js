const L=`당신은 콘텐츠 분석 전문가입니다. 사용자가 웹에서 발견한 글이나 영상의 내용을 분석하여, 사용자의 시간을 절약하고 핵심 가치를 전달하는 것이 목표입니다.

규칙:
1. 모든 응답은 한국어로 작성합니다. 단, 고유명사와 기술 용어는 원문 그대로 유지합니다.
2. 반드시 지정된 JSON 형식으로만 응답합니다. JSON 외의 텍스트는 절대 포함하지 않습니다.
3. JSON 키는 영어로, 값은 한국어로 작성합니다.
4. 추천도 점수 기준:
   - 5점: 반드시 읽어야/봐야 함. 실질적 가치가 매우 높음
   - 4점: 추천. 유용한 인사이트가 있음
   - 3점: 보통. 관심 분야라면 볼 만함
   - 2점: 비추천. 시간 대비 가치가 낮음
   - 1점: 스킵 권장. 내용이 빈약하거나 낚시성`,$=`다음 웹 페이지 내용을 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "coreConcepts": [
    {
      "concept": "핵심 개념 이름",
      "explanation": "이 개념이 무엇인지 초보자도 이해할 수 있게 설명",
      "whyItMatters": "왜 이것이 중요한지"
    }
  ],
  "keyTakeaways": [
    "배울 점 1 - 구체적으로 어떻게 적용할 수 있는지 포함",
    "배울 점 2",
    "배울 점 3"
  ],
  "backgroundContext": "이 내용을 더 잘 이해하기 위해 알면 좋은 배경지식",
  "practicalApplication": "실제로 이 지식을 어떻게 활용할 수 있는지",
  "furtherLearning": "더 깊이 알고 싶다면 찾아볼 키워드나 주제",
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵해도 됨",
    "worthFullRead": true,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,x=`다음 유튜브 영상의 자막/트랜스크립트를 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "videoTitle": "영상 제목 (자막에서 추론)",
  "coreConcepts": [
    {
      "concept": "핵심 개념",
      "explanation": "친절한 설명",
      "timestamp": "MM:SS (해당 내용이 나오는 시점, 없으면 null)"
    }
  ],
  "keyTakeaways": ["배울 점 1", "배울 점 2", "배울 점 3"],
  "backgroundContext": "배경지식",
  "practicalApplication": "실제 활용법",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "이 시점에서 다루는 내용" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,M=`다음 웹 페이지 내용을 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": [
    "핵심 내용 첫 번째 줄",
    "핵심 내용 두 번째 줄",
    "핵심 내용 세 번째 줄"
  ],
  "fullSummary": "전체 내용을 읽지 않아도 맥락을 완전히 이해할 수 있는 상세 요약. 글의 주장, 근거, 결론을 모두 포함하여 3~5 문단으로 작성.",
  "recommendation": {
    "score": 3,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,R=`다음 유튜브 영상의 자막/트랜스크립트를 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": ["첫 번째 줄", "두 번째 줄", "세 번째 줄"],
  "fullSummary": "영상 전체 내용의 상세 요약. 3~5 문단.",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "주요 포인트" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,j="https://generativelanguage.googleapis.com/v1beta/models",V="gemini-2.5-pro";function J(e,a){const t=e.text.length>6e4?e.text.slice(0,6e4)+`

[내용이 너무 길어 일부 생략됨]`:e.text;return a==="learn"?`${e.type==="youtube"?x:$}

제목: ${e.title}
URL: ${e.url}

${t}`:`${e.type==="youtube"?R:M}

제목: ${e.title}
URL: ${e.url}

${t}`}function X(e,a){return a==="learn"?e.type==="youtube"?x:$:e.type==="youtube"?R:M}async function N(e,a,t){const n={contents:[{parts:[{text:J(e,a)}]}],systemInstruction:{parts:[{text:L}]},generationConfig:{maxOutputTokens:4096,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:128}}};return C(n,t)}async function O(e,a,t){const o=e.url,n=X(e,a)+`

제목: ${e.title}
URL: ${o}`;return C({contents:[{parts:[{fileData:{mimeType:"video/mp4",fileUri:o}},{text:n}]}],systemInstruction:{parts:[{text:L}]},generationConfig:{maxOutputTokens:4096,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:128}}},t)}async function C(e,a){var r,u,l,c,h,m;const t=`${j}/${V}:generateContent?key=${a}`,o=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)});if(!o.ok){const K=await o.json().catch(()=>({error:{message:"알 수 없는 오류"}})),g=o.status;throw g===429?new Error("API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."):g===403?new Error("API 키가 유효하지 않습니다. 설정에서 Gemini API 키를 확인해주세요."):new Error(`Gemini API 오류 (${g}): ${((r=K.error)==null?void 0:r.message)??"요청 실패"}`)}const n=await o.json(),i=((c=(l=(u=n.candidates)==null?void 0:u[0])==null?void 0:l.content)==null?void 0:c.parts)??[],s=i.filter(y=>!y.thought&&y.text).pop(),d=(s==null?void 0:s.text)??"";if(!d)throw((m=(h=n.candidates)==null?void 0:h[0])==null?void 0:m.finishReason)==="SAFETY"?new Error("안전 필터에 의해 응답이 차단되었습니다. 다른 콘텐츠로 시도해주세요."):(console.error("[See You Later] Empty Gemini response. Parts:",JSON.stringify(i).slice(0,500)),new Error("AI 응답이 비어있습니다. 다시 시도해주세요."));return q(d)}function q(e){try{return JSON.parse(e.trim())}catch{}const a=e.match(/```(?:json)?\s*([\s\S]*?)```/);if(a)try{return JSON.parse(a[1].trim())}catch{}const t=e.indexOf("{"),o=e.lastIndexOf("}");if(t!==-1&&o>t)try{return JSON.parse(e.slice(t,o+1))}catch{}throw console.error("[See You Later] Failed to parse response:",e.slice(0,500)),new Error("AI 응답을 파싱할 수 없습니다. 다시 시도해주세요.")}const z={defaultMode:"summary",geminiApiKey:"",notionToken:"",notionDatabaseId:"",slackWebhookUrl:"",summaryLanguage:"ko",watchLaterEnabled:!1,watchLaterInterval:60,watchLaterAutoExport:"none"},Z={processedVideoIds:[],lastCheckedAt:0,dailyRequestCount:0,dailyResetDate:""},w="syl_history",k="syl_settings",Q=50;async function p(){const e=await chrome.storage.local.get(k);return{...z,...e[k]??{}}}async function tt(e){const a=await p();await chrome.storage.local.set({[k]:{...a,...e}})}async function v(){return(await chrome.storage.local.get(w))[w]??[]}async function S(e){const a=await v(),t=[e,...a].slice(0,Q);await chrome.storage.local.set({[w]:t})}async function et(){await chrome.storage.local.remove(w)}async function D(e){var a,t;try{const o=await fetch(`https://www.youtube.com/watch?v=${e}`,{headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!o.ok)return null;const i=(await o.text()).match(/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/);if(!i)return null;const s=JSON.parse(i[1]),d=(t=(a=s==null?void 0:s.captions)==null?void 0:a.playerCaptionsTracklistRenderer)==null?void 0:t.captionTracks;if(!d||d.length===0)return null;const r=at(d);if(!r)return null;const u=r.baseUrl+"&fmt=json3",l=await fetch(u);return l.ok?{segments:((await l.json()).events??[]).filter(m=>m.segs&&m.tStartMs!==void 0).map(m=>({text:(m.segs??[]).map(y=>y.utf8??"").join("").replace(/\n/g," ").trim(),start:(m.tStartMs??0)/1e3,duration:(m.dDurationMs??0)/1e3})).filter(m=>m.text.length>0),language:r.languageCode,isAutoGenerated:r.kind==="asr"}:null}catch{return null}}function at(e){const a=[t=>t.languageCode==="ko"&&t.kind!=="asr",t=>t.languageCode.startsWith("en")&&t.kind!=="asr",t=>t.languageCode==="ko",t=>t.languageCode.startsWith("en"),()=>!0];for(const t of a){const o=e.find(t);if(o)return o}return null}function P(e){return e.map(a=>{const t=Math.floor(a.start/60),o=Math.floor(a.start%60);return`[${`${String(t).padStart(2,"0")}:${String(o).padStart(2,"0")}`}] ${a.text}`}).join(`
`)}const U="https://api.notion.com/v1",W="2022-06-28";async function G(e,a,t){const o=t.replace(/-/g,""),i=await ot(o,a)?{database_id:o}:{page_id:o},s=nt(e),d={parent:i,properties:{title:{title:[{text:{content:e.title.slice(0,2e3)}}]}},children:s},r=await fetch(`${U}/pages`,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json","Notion-Version":W},body:JSON.stringify(d)});if(!r.ok){const l=await r.json().catch(()=>({}));throw r.status===403||l.code==="restricted_resource"?new Error(`Notion 접근 권한 없음
저장할 페이지 우측 상단 ··· → 연결 → Integration 선택`):r.status===404?new Error(`Notion 페이지를 찾을 수 없습니다.
설정의 Page ID가 올바른지 확인해주세요.`):new Error(`Notion 저장 오류 (${r.status}): ${l.message??"요청 실패"}`)}const u=await r.json();return u.url??`https://notion.so/${u.id.replace(/-/g,"")}`}async function ot(e,a){try{return(await fetch(`${U}/databases/${e}`,{headers:{Authorization:`Bearer ${a}`,"Notion-Version":W}})).ok}catch{return!1}}function T(e,a=2e3){return[{text:{content:e.slice(0,a)}}]}function nt(e){const a=e.result,t=[],o=(c,h)=>({type:`heading_${h}`,[`heading_${h}`]:{rich_text:T(c)}}),n=c=>({type:"paragraph",paragraph:{rich_text:T(c)}}),i=c=>({type:"bulleted_list_item",bulleted_list_item:{rich_text:T(c)}}),s=()=>({type:"divider",divider:{}}),d=e.contentType==="youtube"?"🎬 유튜브":"📄 웹 페이지",r=a.mode==="learn"?"학습 모드":"일반 모드",u=new Date(e.createdAt).toLocaleString("ko-KR"),l="⭐".repeat(a.recommendation.score);if(t.push(n(`${d} | ${r} | ${u}`)),t.push(n(`🔗 ${e.url}`)),t.push(s()),t.push(o("추천도",2)),t.push(n(`${l} (${a.recommendation.score}/5)  ${a.recommendation.reason}`)),t.push(n(`✅ 추천 대상: ${a.recommendation.bestFor}`)),t.push(n(`⏭️ 스킵 대상: ${a.recommendation.skipIf}`)),t.push(s()),a.mode==="learn")t.push(o("핵심 개념",2)),a.coreConcepts.forEach(c=>{t.push(o(c.concept,3)),t.push(n(c.explanation)),c.whyItMatters&&t.push(n(`💡 ${c.whyItMatters}`))}),t.push(s()),t.push(o("배울 점",2)),a.keyTakeaways.forEach(c=>t.push(i(c))),t.push(s()),t.push(o("실제 적용",2)),t.push(n(a.practicalApplication)),t.push(o("배경 지식",2)),t.push(n(a.backgroundContext)),a.furtherLearning&&(t.push(o("더 알아보기",2)),t.push(n(a.furtherLearning)));else{t.push(o("3줄 요약",2)),a.threeLineSummary.forEach(m=>t.push(i(m))),t.push(s()),t.push(o("전체 요약",2));const c=a.fullSummary,h=1900;for(let m=0;m<c.length;m+=h)t.push(n(c.slice(m,m+h)))}return"keyMoments"in a&&a.keyMoments&&a.keyMoments.length>0&&(t.push(s()),t.push(o("주요 타임스탬프",2)),a.keyMoments.forEach(c=>t.push(i(`[${c.timestamp}] ${c.description}`)))),t.slice(0,100)}const rt=2900;function f(e,a=rt){return e.length>a?e.slice(0,a)+"...":e}async function F(e,a){const t=e.result,o="⭐".repeat(t.recommendation.score),n=e.contentType==="youtube"?"🎬":"📄",i=t.mode==="learn"?"학습 모드":"일반 모드",s=[{type:"header",text:{type:"plain_text",text:`${n} ${e.title}`.slice(0,150),emoji:!0}},{type:"section",fields:[{type:"mrkdwn",text:`*모드:* ${i}`},{type:"mrkdwn",text:`*추천도:* ${o} (${t.recommendation.score}/5)`}]},{type:"section",text:{type:"mrkdwn",text:`*추천 이유:* ${t.recommendation.reason}`}},{type:"section",fields:[{type:"mrkdwn",text:`*✅ 추천 대상:* ${t.recommendation.bestFor}`},{type:"mrkdwn",text:`*⏭️ 스킵 대상:* ${t.recommendation.skipIf}`}]}];if("worthWatching"in t.recommendation&&t.recommendation.worthWatching!==void 0){const r=t.recommendation.worthWatching?"🎬 직접 시청 권장":"📄 요약으로 충분",u=t.recommendation.worthWatchingReason?`: ${t.recommendation.worthWatchingReason}`:"";s.push({type:"section",text:{type:"mrkdwn",text:`*${r}*${u}`}})}if("worthFullRead"in t.recommendation&&t.recommendation.worthFullRead!==void 0){const r=t.recommendation.worthFullRead?"📖 전문 읽기 권장":"📄 요약으로 충분",u=t.recommendation.worthFullReadReason?`: ${t.recommendation.worthFullReadReason}`:"";s.push({type:"section",text:{type:"mrkdwn",text:`*${r}*${u}`}})}if(s.push({type:"divider"}),t.mode==="learn"){const r=t.coreConcepts.map(l=>`*${l.concept}*
${l.explanation}`).join(`

`);s.push({type:"section",text:{type:"mrkdwn",text:`*핵심 개념:*
${f(r)}`}});const u=t.keyTakeaways.map(l=>`• ${l}`).join(`
`);s.push({type:"section",text:{type:"mrkdwn",text:`*배울 점:*
${f(u)}`}}),s.push({type:"section",text:{type:"mrkdwn",text:`*실제 적용:*
${f(t.practicalApplication)}`}})}else{const r=t.threeLineSummary.map(u=>`• ${u}`).join(`
`);s.push({type:"section",text:{type:"mrkdwn",text:`*3줄 요약:*
${r}`}}),s.push({type:"divider"}),s.push({type:"section",text:{type:"mrkdwn",text:`*전체 요약:*
${f(t.fullSummary)}`}})}if("keyMoments"in t&&t.keyMoments&&t.keyMoments.length>0){const r=t.keyMoments.map(u=>`• \`[${u.timestamp}]\` ${u.description}`).join(`
`);s.push({type:"divider"}),s.push({type:"section",text:{type:"mrkdwn",text:`*주요 타임스탬프:*
${f(r,1500)}`}})}s.push({type:"actions",elements:[{type:"button",text:{type:"plain_text",text:"원문 보기",emoji:!0},url:e.url,action_id:"view_original"}]});const d=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({blocks:s})});if(!d.ok)throw new Error(`Slack 전송 오류 (${d.status})`)}const b="syl_watch_later",st=240,it="https://www.youtube.com/playlist?list=WL";async function A(){const e=await chrome.storage.local.get(b),a={...Z,...e[b]??{}},t=new Date().toISOString().slice(0,10);return a.dailyResetDate!==t&&(a.dailyRequestCount=0,a.dailyResetDate=t),a}async function Y(e){await chrome.storage.local.set({[b]:e})}async function E(){const e=await A();e.dailyRequestCount++,await Y(e)}function ct(e){return e.dailyRequestCount<st}async function ut(){var t;let e=null,a=!1;try{const o=await chrome.tabs.query({url:"*://www.youtube.com/playlist?list=WL*"});if(o.length>0&&o[0].id!=null)e=o[0].id;else{if(e=(await chrome.tabs.create({url:it,active:!1})).id??null,a=!0,e==null)return[];await lt(e)}const n=await chrome.scripting.executeScript({target:{tabId:e},func:dt});return((t=n==null?void 0:n[0])==null?void 0:t.result)??[]}catch(o){return console.error("[See You Later] Watch Later fetch failed:",o),[]}finally{a&&e!=null&&chrome.tabs.remove(e).catch(()=>{})}}function lt(e){return new Promise(a=>{const t=setTimeout(()=>{chrome.tabs.onUpdated.removeListener(o),a()},1e4);function o(n,i){n===e&&i.status==="complete"&&(clearTimeout(t),chrome.tabs.onUpdated.removeListener(o),setTimeout(a,1500))}chrome.tabs.onUpdated.addListener(o)})}function dt(){const e=[];try{let a=function(n){var d;const i=[];if(!n||typeof n!="object")return i;if(Array.isArray(n)){for(const r of n)i.push(...a(r));return i}const s=n;if(s.playlistVideoRenderer){const r=s.playlistVideoRenderer,u=r.videoId;if(u){const l=r.title,c=l==null?void 0:l.runs,h=l==null?void 0:l.simpleText,m=((d=c==null?void 0:c[0])==null?void 0:d.text)??h??"제목 없음";return i.push({videoId:u,title:m}),i}}for(const r of Object.keys(s))r==="thumbnail"||r==="playerOverlays"||r==="engagementPanels"||i.push(...a(s[r]));return i};const t=window.ytInitialData;if(!t)return e;const o=a(t);e.push(...o)}catch{}return e}const mt=["chrome://","chrome-extension://","about:","edge://","devtools://"],ht=["accounts.google.com","chromewebstore.google.com","chrome.google.com"],I="watch-later-sync";chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});chrome.runtime.onMessage.addListener((e,a,t)=>(pt(e,t),!0));chrome.alarms.onAlarm.addListener(e=>{e.name===I&&H({manual:!1}).catch(a=>{console.error("Watch Later sync failed:",a)})});chrome.runtime.onInstalled.addListener(()=>{_()});chrome.runtime.onStartup.addListener(()=>{_()});async function _(){const e=await p();await chrome.alarms.clear(I),e.watchLaterEnabled&&chrome.alarms.create(I,{periodInMinutes:e.watchLaterInterval})}async function pt(e,a){try{switch(e.type){case"EXTRACT_AND_SUMMARIZE":{const{mode:t}=e.payload,o=await wt(t);a({success:!0,data:o});break}case"SUMMARIZE":{const{content:t,mode:o}=e.payload,n=await B(t,o);a({success:!0,data:n});break}case"GET_SETTINGS":{const t=await p();a({success:!0,data:t});break}case"SAVE_SETTINGS":{const t=e.payload;await tt(t),await _(),a({success:!0});break}case"GET_HISTORY":{const t=await v();a({success:!0,data:t});break}case"CLEAR_HISTORY":{await et(),a({success:!0});break}case"EXPORT_NOTION":{const{item:t}=e.payload,o=await p();if(!o.notionToken||!o.notionDatabaseId){a({success:!1,error:"Notion 설정이 완료되지 않았습니다."});break}const n=await G(t,o.notionToken,o.notionDatabaseId);a({success:!0,data:{url:n}});break}case"EXPORT_SLACK":{const{item:t}=e.payload,o=await p();if(!o.slackWebhookUrl){a({success:!1,error:"Slack Webhook URL이 설정되지 않았습니다."});break}await F(t,o.slackWebhookUrl),a({success:!0});break}case"SYNC_WATCH_LATER":{H({manual:!0}).then(t=>a({success:!0,data:{count:t}})).catch(t=>a({success:!1,error:t.message}));return}case"GET_WATCH_LATER_STATUS":{const t=await A();a({success:!0,data:t});break}default:a({success:!1,error:"알 수 없는 메시지 타입"})}}catch(t){const o=t instanceof Error?t.message:"알 수 없는 오류가 발생했습니다.";a({success:!1,error:o})}}function yt(e){if(mt.some(a=>e.startsWith(a)))return!0;try{const a=new URL(e);return ht.includes(a.hostname)}catch{return!0}}async function ft(e){try{await chrome.scripting.executeScript({target:{tabId:e},files:["content/extractor.js"]})}catch{}return await new Promise(a=>setTimeout(a,150)),new Promise((a,t)=>{chrome.tabs.sendMessage(e,{type:"EXTRACT_CONTENT"},o=>{if(chrome.runtime.lastError){t(new Error("페이지와 통신할 수 없습니다. 페이지를 새로고침 후 다시 시도해주세요."));return}if(!(o!=null&&o.success)||!o.data){t(new Error((o==null?void 0:o.error)??"페이지 내용을 추출할 수 없습니다."));return}a(o.data)})})}async function wt(e){const t=(await chrome.tabs.query({active:!0,lastFocusedWindow:!0}))[0];if(!(t!=null&&t.id)||!t.url)throw new Error("현재 탭을 찾을 수 없습니다. 웹 페이지를 열고 다시 시도해주세요.");if(yt(t.url))throw new Error("이 페이지에서는 요약할 수 없습니다. 일반 웹 페이지나 유튜브에서 사용해주세요.");const o=await ft(t.id);if(o.type==="webpage"&&!o.text)throw new Error("이 페이지에서 요약할 콘텐츠를 찾을 수 없습니다. 기사나 블로그 같은 텍스트가 있는 페이지에서 사용해주세요.");return B(o,e)}async function B(e,a){const t=await p();if(!t.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다. 설정 탭에서 입력해주세요.");let o=e;if(e.type==="youtube"&&!e.text&&e.videoId){const s=await D(e.videoId);if(s&&s.segments.length>0)o={...e,text:P(s.segments),hasSubtitles:!0};else{await E();const d=await O(e,a,t.geminiApiKey),r={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:d,createdAt:Date.now()};return await S(r),{result:d,historyItem:r}}}await E();const n=await N(o,a,t.geminiApiKey),i={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:n,createdAt:Date.now()};return await S(i),{result:n,historyItem:i}}async function H(e){const a=await p();if(!a.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다.");if(!(e!=null&&e.manual)&&!a.watchLaterEnabled)return 0;const t=(a.watchLaterAutoExport==="slack"||a.watchLaterAutoExport==="both")&&!!a.slackWebhookUrl,o=(a.watchLaterAutoExport==="notion"||a.watchLaterAutoExport==="both")&&!!a.notionToken&&!!a.notionDatabaseId,n=await A(),i=await ut();if(i.length===0)throw new Error(`"나중에 볼 동영상" 목록을 가져올 수 없습니다.
YouTube에 로그인되어 있는지 확인하고, YouTube 탭이 열려 있으면 새로고침 후 다시 시도해주세요.`);const s=n.processedVideoIds.length===0?i:i.filter(r=>!n.processedVideoIds.includes(r.videoId));if(s.length===0)return 0;let d=0;for(const r of s){if(!ct(n))break;try{const u={type:"youtube",title:r.title,text:"",url:`https://www.youtube.com/watch?v=${r.videoId}`,videoId:r.videoId},l=await D(r.videoId);let c;l&&l.segments.length>0?(u.text=P(l.segments),u.hasSubtitles=!0,c=await N(u,a.defaultMode,a.geminiApiKey)):c=await O(u,a.defaultMode,a.geminiApiKey),await E();const h={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:u.url,title:r.title,contentType:"youtube",mode:a.defaultMode,result:c,createdAt:Date.now()};await S(h),t&&await F(h,a.slackWebhookUrl).catch(()=>{}),o&&await G(h,a.notionToken,a.notionDatabaseId).catch(()=>{}),n.processedVideoIds.push(r.videoId),d++,await new Promise(m=>setTimeout(m,6500))}catch{continue}}if(n.lastCheckedAt=Date.now(),n.processedVideoIds.length>500&&(n.processedVideoIds=n.processedVideoIds.slice(-500)),await Y(n),d>0){const r=t&&o?"Slack과 Notion":t?"Slack":"Notion";chrome.notifications.create({type:"basic",iconUrl:chrome.runtime.getURL("icons/icon-128.png"),title:"See You Later",message:`${d}개의 새 영상 요약이 ${r}으로 전송되었습니다.`})}return d}
