const C=`당신은 콘텐츠 분석 전문가입니다. 사용자가 웹에서 발견한 글이나 영상의 내용을 분석하여, 사용자의 시간을 절약하고 핵심 가치를 전달하는 것이 목표입니다.

규칙:
1. 모든 응답은 한국어로 작성합니다. 단, 고유명사와 기술 용어는 원문 그대로 유지합니다.
2. 반드시 지정된 JSON 형식으로만 응답합니다. JSON 외의 텍스트는 절대 포함하지 않습니다.
3. JSON 키는 영어로, 값은 한국어로 작성합니다.
4. 추천도 점수 기준:
   - 5점: 반드시 읽어야/봐야 함. 실질적 가치가 매우 높음
   - 4점: 추천. 유용한 인사이트가 있음
   - 3점: 보통. 관심 분야라면 볼 만함
   - 2점: 비추천. 시간 대비 가치가 낮음
   - 1점: 스킵 권장. 내용이 빈약하거나 낚시성`,P=`다음 웹 페이지 내용을 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "coreConcepts": [
    {
      "concept": "핵심 개념 이름",
      "explanation": "이 개념이 무엇인지 초보자도 이해할 수 있게 설명",
      "whyItMatters": "왜 이것이 중요한지"
    }
  ],
  "keyTakeaways": [
    "배울 점 1 - 구체적으로 어떻게 적용할 수 있는지 포함",
    "배울 점 2",
    "배울 점 3"
  ],
  "backgroundContext": "이 내용을 더 잘 이해하기 위해 알면 좋은 배경지식",
  "practicalApplication": "실제로 이 지식을 어떻게 활용할 수 있는지",
  "furtherLearning": "더 깊이 알고 싶다면 찾아볼 키워드나 주제",
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵해도 됨",
    "worthFullRead": true,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,D=`다음 유튜브 영상의 자막/트랜스크립트를 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "videoTitle": "영상 제목 (자막에서 추론)",
  "coreConcepts": [
    {
      "concept": "핵심 개념",
      "explanation": "친절한 설명",
      "timestamp": "MM:SS (해당 내용이 나오는 시점, 없으면 null)"
    }
  ],
  "keyTakeaways": ["배울 점 1", "배울 점 2", "배울 점 3"],
  "backgroundContext": "배경지식",
  "practicalApplication": "실제 활용법",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "이 시점에서 다루는 내용" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,U=`다음 웹 페이지 내용을 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": [
    "핵심 내용 첫 번째 줄",
    "핵심 내용 두 번째 줄",
    "핵심 내용 세 번째 줄"
  ],
  "fullSummary": "전체 내용을 읽지 않아도 맥락을 완전히 이해할 수 있는 상세 요약. 글의 주장, 근거, 결론을 모두 포함하여 3~5 문단으로 작성.",
  "recommendation": {
    "score": 3,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,v=`다음 유튜브 영상의 자막/트랜스크립트를 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": ["첫 번째 줄", "두 번째 줄", "세 번째 줄"],
  "fullSummary": "영상 전체 내용의 상세 요약. 3~5 문단.",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "주요 포인트" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,z="https://generativelanguage.googleapis.com/v1beta/models",Z="gemini-2.5-flash";function Q(e,a){const t=e.text.length>6e4?e.text.slice(0,6e4)+`

[내용이 너무 길어 일부 생략됨]`:e.text;return a==="learn"?`${e.type==="youtube"?D:P}

제목: ${e.title}
URL: ${e.url}

${t}`:`${e.type==="youtube"?v:U}

제목: ${e.title}
URL: ${e.url}

${t}`}function tt(e,a){return a==="learn"?e.type==="youtube"?D:P:e.type==="youtube"?v:U}async function W(e,a,t){const n={contents:[{parts:[{text:Q(e,a)}]}],systemInstruction:{parts:[{text:C}]},generationConfig:{maxOutputTokens:2048,responseMimeType:"application/json"}};return G(n,t)}async function j(e,a,t){const o=e.url,n=tt(e,a)+`

제목: ${e.title}
URL: ${o}`;return G({contents:[{parts:[{fileData:{mimeType:"video/mp4",fileUri:o}},{text:n}]}],systemInstruction:{parts:[{text:C}]},generationConfig:{maxOutputTokens:2048,responseMimeType:"application/json"}},t)}async function G(e,a){var r,u,d,m,h,l,p,w;const t=`${z}/${Z}:generateContent?key=${a}`,o=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)});if(!o.ok){const T=await o.json().catch(()=>({error:{message:"알 수 없는 오류"}})),f=o.status;throw f===429?new Error("API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."):f===403?new Error("API 키가 유효하지 않습니다. 설정에서 Gemini API 키를 확인해주세요."):new Error(`Gemini API 오류 (${f}): ${((r=T.error)==null?void 0:r.message)??"요청 실패"}`)}const n=await o.json(),c=((l=(h=(m=(d=(u=n.candidates)==null?void 0:u[0])==null?void 0:d.content)==null?void 0:m.parts)==null?void 0:h[0])==null?void 0:l.text)??"";if(!c)throw((w=(p=n.candidates)==null?void 0:p[0])==null?void 0:w.finishReason)==="SAFETY"?new Error("안전 필터에 의해 응답이 차단되었습니다. 다른 콘텐츠로 시도해주세요."):new Error("AI 응답이 비어있습니다. 다시 시도해주세요.");const s=c.match(/```(?:json)?\s*([\s\S]*?)```/)??null,i=s?s[1]:c;try{return JSON.parse(i.trim())}catch{throw new Error("AI 응답을 파싱할 수 없습니다. 다시 시도해주세요.")}}const et={defaultMode:"summary",geminiApiKey:"",notionToken:"",notionDatabaseId:"",slackWebhookUrl:"",summaryLanguage:"ko",watchLaterEnabled:!1,watchLaterInterval:60,watchLaterAutoExport:"none"},at={processedVideoIds:[],lastCheckedAt:0,dailyRequestCount:0,dailyResetDate:""},k="syl_history",I="syl_settings",ot=50;async function y(){const e=await chrome.storage.local.get(I);return{...et,...e[I]??{}}}async function rt(e){const a=await y();await chrome.storage.local.set({[I]:{...a,...e}})}async function H(){return(await chrome.storage.local.get(k))[k]??[]}async function _(e){const a=await H(),t=[e,...a].slice(0,ot);await chrome.storage.local.set({[k]:t})}async function nt(){await chrome.storage.local.remove(k)}async function Y(e){var a,t;try{const o=await fetch(`https://www.youtube.com/watch?v=${e}`,{headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!o.ok)return null;const c=(await o.text()).match(/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/);if(!c)return null;const s=JSON.parse(c[1]),i=(t=(a=s==null?void 0:s.captions)==null?void 0:a.playerCaptionsTracklistRenderer)==null?void 0:t.captionTracks;if(!i||i.length===0)return null;const r=st(i);if(!r)return null;const u=r.baseUrl+"&fmt=json3",d=await fetch(u);return d.ok?{segments:((await d.json()).events??[]).filter(l=>l.segs&&l.tStartMs!==void 0).map(l=>({text:(l.segs??[]).map(p=>p.utf8??"").join("").replace(/\n/g," ").trim(),start:(l.tStartMs??0)/1e3,duration:(l.dDurationMs??0)/1e3})).filter(l=>l.text.length>0),language:r.languageCode,isAutoGenerated:r.kind==="asr"}:null}catch{return null}}function st(e){const a=[t=>t.languageCode==="ko"&&t.kind!=="asr",t=>t.languageCode.startsWith("en")&&t.kind!=="asr",t=>t.languageCode==="ko",t=>t.languageCode.startsWith("en"),()=>!0];for(const t of a){const o=e.find(t);if(o)return o}return null}function F(e){return e.map(a=>{const t=Math.floor(a.start/60),o=Math.floor(a.start%60);return`[${`${String(t).padStart(2,"0")}:${String(o).padStart(2,"0")}`}] ${a.text}`}).join(`
`)}const it="https://api.notion.com/v1",ct="2022-06-28";async function K(e,a,t){const o=e.result,n=o.mode==="learn",c=ut(e),s=await fetch(`${it}/pages`,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json","Notion-Version":ct},body:JSON.stringify({parent:{database_id:t},properties:{title:{title:[{text:{content:e.title}}]},URL:{url:e.url},타입:{select:{name:e.contentType==="youtube"?"유튜브":"웹 페이지"}},모드:{select:{name:n?"학습 모드":"일반 모드"}},추천도:{number:o.recommendation.score},저장일:{date:{start:new Date(e.createdAt).toISOString()}}},children:c})});if(!s.ok){const r=await s.json().catch(()=>({message:"알 수 없는 오류"}));throw new Error(`Notion 저장 오류 (${s.status}): ${r.message??"요청 실패"}`)}const i=await s.json();return i.url??`https://notion.so/${i.id}`}function ut(e){const a=e.result,t=[],o=(r,u)=>({type:`heading_${u}`,[`heading_${u}`]:{rich_text:[{text:{content:r}}]}}),n=r=>({type:"paragraph",paragraph:{rich_text:[{text:{content:r}}]}}),c=r=>({type:"bulleted_list_item",bulleted_list_item:{rich_text:[{text:{content:r}}]}}),s=()=>({type:"divider",divider:{}});t.push(o("추천도",2));const i="⭐".repeat(a.recommendation.score);return t.push(n(`${i} (${a.recommendation.score}/5)`)),t.push(n(`📌 ${a.recommendation.reason}`)),t.push(n(`✅ 추천 대상: ${a.recommendation.bestFor}`)),t.push(n(`⏭️ 스킵 대상: ${a.recommendation.skipIf}`)),t.push(s()),a.mode==="learn"?(t.push(o("핵심 개념",2)),a.coreConcepts.forEach(r=>{t.push(o(r.concept,3)),t.push(n(r.explanation)),r.whyItMatters&&t.push(n(`💡 ${r.whyItMatters}`))}),t.push(s()),t.push(o("배울 점",2)),a.keyTakeaways.forEach(r=>t.push(c(r))),t.push(s()),t.push(o("배경 지식",2)),t.push(n(a.backgroundContext)),t.push(o("실제 적용",2)),t.push(n(a.practicalApplication)),a.furtherLearning&&(t.push(o("더 알아보기",2)),t.push(n(a.furtherLearning)))):(t.push(o("3줄 요약",2)),a.threeLineSummary.forEach(r=>t.push(c(r))),t.push(s()),t.push(o("전체 요약",2)),t.push(n(a.fullSummary))),"keyMoments"in a&&a.keyMoments&&a.keyMoments.length>0&&(t.push(s()),t.push(o("주요 타임스탬프",2)),a.keyMoments.forEach(r=>t.push(c(`[${r.timestamp}] ${r.description}`)))),t}async function V(e,a){const t=e.result,o="⭐".repeat(t.recommendation.score),n=e.contentType==="youtube"?"🎬":"📄",c=t.mode==="learn"?"학습 모드":"일반 모드";let s="";t.mode==="learn"?s=t.keyTakeaways.map(u=>`• ${u}`).join(`
`):s=t.threeLineSummary.map(u=>`• ${u}`).join(`
`);const i={blocks:[{type:"header",text:{type:"plain_text",text:`${n} ${e.title}`,emoji:!0}},{type:"section",fields:[{type:"mrkdwn",text:`*모드:* ${c}`},{type:"mrkdwn",text:`*추천도:* ${o} (${t.recommendation.score}/5)`}]},{type:"section",text:{type:"mrkdwn",text:`*추천 이유:* ${t.recommendation.reason}`}},{type:"divider"},{type:"section",text:{type:"mrkdwn",text:`*핵심 내용:*
${s}`}},{type:"actions",elements:[{type:"button",text:{type:"plain_text",text:"원문 보기",emoji:!0},url:e.url,action_id:"view_original"}]}]},r=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)});if(!r.ok)throw new Error(`Slack 전송 오류 (${r.status})`)}const L="syl_watch_later",lt=240;async function R(){const e=await chrome.storage.local.get(L),a={...at,...e[L]??{}},t=new Date().toISOString().slice(0,10);return a.dailyResetDate!==t&&(a.dailyRequestCount=0,a.dailyResetDate=t),a}async function B(e){await chrome.storage.local.set({[L]:e})}async function M(){const e=await R();e.dailyRequestCount++,await B(e)}function dt(e){return e.dailyRequestCount<lt}async function mt(){try{const e=await fetch("https://www.youtube.com/playlist?list=WL",{credentials:"include",headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!e.ok)return[];const a=await e.text();return ht(a)}catch{return[]}}function ht(e){var o,n,c,s,i,r,u,d,m,h,l,p,w,g,T,f,$;const a=[],t=e.match(/var\s+ytInitialData\s*=\s*({.+?});\s*<\/script>/s);if(!t)return a;try{const E=JSON.parse(t[1]),N=(w=(p=(l=(h=(m=(d=(u=(r=(i=(s=(c=(n=(o=E==null?void 0:E.contents)==null?void 0:o.twoColumnBrowseResultsRenderer)==null?void 0:n.tabs)==null?void 0:c[0])==null?void 0:s.tabRenderer)==null?void 0:i.content)==null?void 0:r.sectionListRenderer)==null?void 0:u.contents)==null?void 0:d[0])==null?void 0:m.itemSectionRenderer)==null?void 0:h.contents)==null?void 0:l[0])==null?void 0:p.playlistVideoListRenderer)==null?void 0:w.contents;if(!Array.isArray(N))return a;for(const b of N){const S=b==null?void 0:b.playlistVideoRenderer;if(!S)continue;const A=S.videoId,X=((f=(T=(g=S.title)==null?void 0:g.runs)==null?void 0:T[0])==null?void 0:f.text)??(($=S.title)==null?void 0:$.simpleText)??"제목 없음";A&&typeof A=="string"&&a.push({videoId:A,title:X})}}catch{return a}return a}const pt=["chrome://","chrome-extension://","about:","edge://","devtools://"],yt=["accounts.google.com","chromewebstore.google.com","chrome.google.com"],x="watch-later-sync";chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});chrome.runtime.onMessage.addListener((e,a,t)=>(ft(e,t),!0));chrome.alarms.onAlarm.addListener(e=>{e.name===x&&q().catch(a=>{console.error("Watch Later sync failed:",a)})});chrome.runtime.onInstalled.addListener(()=>{O()});chrome.runtime.onStartup.addListener(()=>{O()});async function O(){const e=await y();await chrome.alarms.clear(x),e.watchLaterEnabled&&chrome.alarms.create(x,{periodInMinutes:e.watchLaterInterval})}async function ft(e,a){try{switch(e.type){case"EXTRACT_AND_SUMMARIZE":{const{mode:t}=e.payload,o=await Tt(t);a({success:!0,data:o});break}case"SUMMARIZE":{const{content:t,mode:o}=e.payload,n=await J(t,o);a({success:!0,data:n});break}case"GET_SETTINGS":{const t=await y();a({success:!0,data:t});break}case"SAVE_SETTINGS":{const t=e.payload;await rt(t),await O(),a({success:!0});break}case"GET_HISTORY":{const t=await H();a({success:!0,data:t});break}case"CLEAR_HISTORY":{await nt(),a({success:!0});break}case"EXPORT_NOTION":{const{item:t}=e.payload,o=await y();if(!o.notionToken||!o.notionDatabaseId){a({success:!1,error:"Notion 설정이 완료되지 않았습니다."});break}const n=await K(t,o.notionToken,o.notionDatabaseId);a({success:!0,data:{url:n}});break}case"EXPORT_SLACK":{const{item:t}=e.payload,o=await y();if(!o.slackWebhookUrl){a({success:!1,error:"Slack Webhook URL이 설정되지 않았습니다."});break}await V(t,o.slackWebhookUrl),a({success:!0});break}case"SYNC_WATCH_LATER":{q().then(t=>a({success:!0,data:{count:t}})).catch(t=>a({success:!1,error:t.message}));return}case"GET_WATCH_LATER_STATUS":{const t=await R();a({success:!0,data:t});break}default:a({success:!1,error:"알 수 없는 메시지 타입"})}}catch(t){const o=t instanceof Error?t.message:"알 수 없는 오류가 발생했습니다.";a({success:!1,error:o})}}function wt(e){if(pt.some(a=>e.startsWith(a)))return!0;try{const a=new URL(e);return yt.includes(a.hostname)}catch{return!0}}async function gt(e){try{await chrome.scripting.executeScript({target:{tabId:e},files:["content/extractor.js"]})}catch{}return await new Promise(a=>setTimeout(a,150)),new Promise((a,t)=>{chrome.tabs.sendMessage(e,{type:"EXTRACT_CONTENT"},o=>{if(chrome.runtime.lastError){t(new Error("페이지와 통신할 수 없습니다. 페이지를 새로고침 후 다시 시도해주세요."));return}if(!(o!=null&&o.success)||!o.data){t(new Error((o==null?void 0:o.error)??"페이지 내용을 추출할 수 없습니다."));return}a(o.data)})})}async function Tt(e){const t=(await chrome.tabs.query({active:!0,lastFocusedWindow:!0}))[0];if(!(t!=null&&t.id)||!t.url)throw new Error("현재 탭을 찾을 수 없습니다. 웹 페이지를 열고 다시 시도해주세요.");if(wt(t.url))throw new Error("이 페이지에서는 요약할 수 없습니다. 일반 웹 페이지나 유튜브에서 사용해주세요.");const o=await gt(t.id);if(o.type==="webpage"&&!o.text)throw new Error("이 페이지에서 요약할 콘텐츠를 찾을 수 없습니다. 기사나 블로그 같은 텍스트가 있는 페이지에서 사용해주세요.");return J(o,e)}async function J(e,a){const t=await y();if(!t.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다. 설정 탭에서 입력해주세요.");let o=e;if(e.type==="youtube"&&!e.text&&e.videoId){const s=await Y(e.videoId);if(s&&s.segments.length>0)o={...e,text:F(s.segments),hasSubtitles:!0};else{await M();const i=await j(e,a,t.geminiApiKey),r={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:i,createdAt:Date.now()};return await _(r),{result:i,historyItem:r}}}await M();const n=await W(o,a,t.geminiApiKey),c={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:n,createdAt:Date.now()};return await _(c),{result:n,historyItem:c}}async function q(){const e=await y();if(!e.watchLaterEnabled||!e.geminiApiKey||e.watchLaterAutoExport==="none")return 0;const a=e.watchLaterAutoExport!=="notion"&&!!e.slackWebhookUrl,t=e.watchLaterAutoExport!=="slack"&&!!e.notionToken&&!!e.notionDatabaseId;if(!a&&!t)return 0;const o=await R(),n=await mt();if(n.length===0)return 0;const c=o.processedVideoIds.length===0?n:n.filter(i=>!o.processedVideoIds.includes(i.videoId));if(c.length===0)return 0;let s=0;for(const i of c){if(!dt(o))break;try{const r={type:"youtube",title:i.title,text:"",url:`https://www.youtube.com/watch?v=${i.videoId}`,videoId:i.videoId},u=await Y(i.videoId);let d;u&&u.segments.length>0?(r.text=F(u.segments),r.hasSubtitles=!0,d=await W(r,e.defaultMode,e.geminiApiKey)):d=await j(r,e.defaultMode,e.geminiApiKey),await M();const m={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:r.url,title:i.title,contentType:"youtube",mode:e.defaultMode,result:d,createdAt:Date.now()};await _(m),a&&await V(m,e.slackWebhookUrl).catch(()=>{}),t&&await K(m,e.notionToken,e.notionDatabaseId).catch(()=>{}),o.processedVideoIds.push(i.videoId),s++,await new Promise(h=>setTimeout(h,6500))}catch{continue}}if(o.lastCheckedAt=Date.now(),o.processedVideoIds.length>500&&(o.processedVideoIds=o.processedVideoIds.slice(-500)),await B(o),s>0){const i=a&&t?"Slack과 Notion":a?"Slack":"Notion";chrome.notifications.create({type:"basic",iconUrl:chrome.runtime.getURL("icons/icon-128.png"),title:"See You Later",message:`${s}개의 새 영상 요약이 ${i}으로 전송되었습니다.`})}return s}
