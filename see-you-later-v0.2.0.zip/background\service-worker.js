const C=`당신은 콘텐츠 분석 전문가입니다. 사용자가 웹에서 발견한 글이나 영상의 내용을 분석하여, 사용자의 시간을 절약하고 핵심 가치를 전달하는 것이 목표입니다.

규칙:
1. 모든 응답은 한국어로 작성합니다. 단, 고유명사와 기술 용어는 원문 그대로 유지합니다.
2. 반드시 지정된 JSON 형식으로만 응답합니다. JSON 외의 텍스트는 절대 포함하지 않습니다.
3. JSON 키는 영어로, 값은 한국어로 작성합니다.
4. 추천도 점수 기준:
   - 5점: 반드시 읽어야/봐야 함. 실질적 가치가 매우 높음
   - 4점: 추천. 유용한 인사이트가 있음
   - 3점: 보통. 관심 분야라면 볼 만함
   - 2점: 비추천. 시간 대비 가치가 낮음
   - 1점: 스킵 권장. 내용이 빈약하거나 낚시성`,P=`다음 웹 페이지 내용을 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "coreConcepts": [
    {
      "concept": "핵심 개념 이름",
      "explanation": "이 개념이 무엇인지 초보자도 이해할 수 있게 설명",
      "whyItMatters": "왜 이것이 중요한지"
    }
  ],
  "keyTakeaways": [
    "배울 점 1 - 구체적으로 어떻게 적용할 수 있는지 포함",
    "배울 점 2",
    "배울 점 3"
  ],
  "backgroundContext": "이 내용을 더 잘 이해하기 위해 알면 좋은 배경지식",
  "practicalApplication": "실제로 이 지식을 어떻게 활용할 수 있는지",
  "furtherLearning": "더 깊이 알고 싶다면 찾아볼 키워드나 주제",
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵해도 됨",
    "worthFullRead": true,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,D=`다음 유튜브 영상의 자막/트랜스크립트를 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "videoTitle": "영상 제목 (자막에서 추론)",
  "coreConcepts": [
    {
      "concept": "핵심 개념",
      "explanation": "친절한 설명",
      "timestamp": "MM:SS (해당 내용이 나오는 시점, 없으면 null)"
    }
  ],
  "keyTakeaways": ["배울 점 1", "배울 점 2", "배울 점 3"],
  "backgroundContext": "배경지식",
  "practicalApplication": "실제 활용법",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "이 시점에서 다루는 내용" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,U=`다음 웹 페이지 내용을 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": [
    "핵심 내용 첫 번째 줄",
    "핵심 내용 두 번째 줄",
    "핵심 내용 세 번째 줄"
  ],
  "fullSummary": "전체 내용을 읽지 않아도 맥락을 완전히 이해할 수 있는 상세 요약. 글의 주장, 근거, 결론을 모두 포함하여 3~5 문단으로 작성.",
  "recommendation": {
    "score": 3,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,v=`다음 유튜브 영상의 자막/트랜스크립트를 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": ["첫 번째 줄", "두 번째 줄", "세 번째 줄"],
  "fullSummary": "영상 전체 내용의 상세 요약. 3~5 문단.",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "주요 포인트" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,z="https://generativelanguage.googleapis.com/v1beta/models",Z="gemini-2.5-flash";function Q(t,a){const e=t.text.length>6e4?t.text.slice(0,6e4)+`

[내용이 너무 길어 일부 생략됨]`:t.text;return a==="learn"?`${t.type==="youtube"?D:P}

제목: ${t.title}
URL: ${t.url}

${e}`:`${t.type==="youtube"?v:U}

제목: ${t.title}
URL: ${t.url}

${e}`}function tt(t,a){return a==="learn"?t.type==="youtube"?D:P:t.type==="youtube"?v:U}async function W(t,a,e){const r={contents:[{parts:[{text:Q(t,a)}]}],systemInstruction:{parts:[{text:C}]},generationConfig:{maxOutputTokens:2048,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:0}}};return Y(r,e)}async function j(t,a,e){const n=t.url,r=tt(t,a)+`

제목: ${t.title}
URL: ${n}`;return Y({contents:[{parts:[{fileData:{mimeType:"video/mp4",fileUri:n}},{text:r}]}],systemInstruction:{parts:[{text:C}]},generationConfig:{maxOutputTokens:2048,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:0}}},e)}async function Y(t,a){var o,u,d,h,p,l;const e=`${z}/${Z}:generateContent?key=${a}`,n=await fetch(e,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(t)});if(!n.ok){const w=await n.json().catch(()=>({error:{message:"알 수 없는 오류"}})),f=n.status;throw f===429?new Error("API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."):f===403?new Error("API 키가 유효하지 않습니다. 설정에서 Gemini API 키를 확인해주세요."):new Error(`Gemini API 오류 (${f}): ${((o=w.error)==null?void 0:o.message)??"요청 실패"}`)}const r=await n.json(),c=((h=(d=(u=r.candidates)==null?void 0:u[0])==null?void 0:d.content)==null?void 0:h.parts)??[],s=c.filter(m=>!m.thought&&m.text).pop(),i=(s==null?void 0:s.text)??"";if(!i)throw((l=(p=r.candidates)==null?void 0:p[0])==null?void 0:l.finishReason)==="SAFETY"?new Error("안전 필터에 의해 응답이 차단되었습니다. 다른 콘텐츠로 시도해주세요."):(console.error("[See You Later] Empty Gemini response. Parts:",JSON.stringify(c).slice(0,500)),new Error("AI 응답이 비어있습니다. 다시 시도해주세요."));return et(i)}function et(t){try{return JSON.parse(t.trim())}catch{}const a=t.match(/```(?:json)?\s*([\s\S]*?)```/);if(a)try{return JSON.parse(a[1].trim())}catch{}const e=t.indexOf("{"),n=t.lastIndexOf("}");if(e!==-1&&n>e)try{return JSON.parse(t.slice(e,n+1))}catch{}throw console.error("[See You Later] Failed to parse response:",t.slice(0,500)),new Error("AI 응답을 파싱할 수 없습니다. 다시 시도해주세요.")}const at={defaultMode:"summary",geminiApiKey:"",notionToken:"",notionDatabaseId:"",slackWebhookUrl:"",summaryLanguage:"ko",watchLaterEnabled:!1,watchLaterInterval:60,watchLaterAutoExport:"none"},nt={processedVideoIds:[],lastCheckedAt:0,dailyRequestCount:0,dailyResetDate:""},S="syl_history",b="syl_settings",ot=50;async function y(){const t=await chrome.storage.local.get(b);return{...at,...t[b]??{}}}async function rt(t){const a=await y();await chrome.storage.local.set({[b]:{...a,...t}})}async function G(){return(await chrome.storage.local.get(S))[S]??[]}async function I(t){const a=await G(),e=[t,...a].slice(0,ot);await chrome.storage.local.set({[S]:e})}async function st(){await chrome.storage.local.remove(S)}async function H(t){var a,e;try{const n=await fetch(`https://www.youtube.com/watch?v=${t}`,{headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!n.ok)return null;const c=(await n.text()).match(/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/);if(!c)return null;const s=JSON.parse(c[1]),i=(e=(a=s==null?void 0:s.captions)==null?void 0:a.playerCaptionsTracklistRenderer)==null?void 0:e.captionTracks;if(!i||i.length===0)return null;const o=it(i);if(!o)return null;const u=o.baseUrl+"&fmt=json3",d=await fetch(u);return d.ok?{segments:((await d.json()).events??[]).filter(l=>l.segs&&l.tStartMs!==void 0).map(l=>({text:(l.segs??[]).map(m=>m.utf8??"").join("").replace(/\n/g," ").trim(),start:(l.tStartMs??0)/1e3,duration:(l.dDurationMs??0)/1e3})).filter(l=>l.text.length>0),language:o.languageCode,isAutoGenerated:o.kind==="asr"}:null}catch{return null}}function it(t){const a=[e=>e.languageCode==="ko"&&e.kind!=="asr",e=>e.languageCode.startsWith("en")&&e.kind!=="asr",e=>e.languageCode==="ko",e=>e.languageCode.startsWith("en"),()=>!0];for(const e of a){const n=t.find(e);if(n)return n}return null}function B(t){return t.map(a=>{const e=Math.floor(a.start/60),n=Math.floor(a.start%60);return`[${`${String(e).padStart(2,"0")}:${String(n).padStart(2,"0")}`}] ${a.text}`}).join(`
`)}const ct="https://api.notion.com/v1",ut="2022-06-28";async function F(t,a,e){const n=t.result,r=n.mode==="learn",c=lt(t),s=await fetch(`${ct}/pages`,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json","Notion-Version":ut},body:JSON.stringify({parent:{database_id:e},properties:{title:{title:[{text:{content:t.title}}]},URL:{url:t.url},타입:{select:{name:t.contentType==="youtube"?"유튜브":"웹 페이지"}},모드:{select:{name:r?"학습 모드":"일반 모드"}},추천도:{number:n.recommendation.score},저장일:{date:{start:new Date(t.createdAt).toISOString()}}},children:c})});if(!s.ok){const o=await s.json().catch(()=>({message:"알 수 없는 오류"}));throw new Error(`Notion 저장 오류 (${s.status}): ${o.message??"요청 실패"}`)}const i=await s.json();return i.url??`https://notion.so/${i.id}`}function lt(t){const a=t.result,e=[],n=(o,u)=>({type:`heading_${u}`,[`heading_${u}`]:{rich_text:[{text:{content:o}}]}}),r=o=>({type:"paragraph",paragraph:{rich_text:[{text:{content:o}}]}}),c=o=>({type:"bulleted_list_item",bulleted_list_item:{rich_text:[{text:{content:o}}]}}),s=()=>({type:"divider",divider:{}});e.push(n("추천도",2));const i="⭐".repeat(a.recommendation.score);return e.push(r(`${i} (${a.recommendation.score}/5)`)),e.push(r(`📌 ${a.recommendation.reason}`)),e.push(r(`✅ 추천 대상: ${a.recommendation.bestFor}`)),e.push(r(`⏭️ 스킵 대상: ${a.recommendation.skipIf}`)),e.push(s()),a.mode==="learn"?(e.push(n("핵심 개념",2)),a.coreConcepts.forEach(o=>{e.push(n(o.concept,3)),e.push(r(o.explanation)),o.whyItMatters&&e.push(r(`💡 ${o.whyItMatters}`))}),e.push(s()),e.push(n("배울 점",2)),a.keyTakeaways.forEach(o=>e.push(c(o))),e.push(s()),e.push(n("배경 지식",2)),e.push(r(a.backgroundContext)),e.push(n("실제 적용",2)),e.push(r(a.practicalApplication)),a.furtherLearning&&(e.push(n("더 알아보기",2)),e.push(r(a.furtherLearning)))):(e.push(n("3줄 요약",2)),a.threeLineSummary.forEach(o=>e.push(c(o))),e.push(s()),e.push(n("전체 요약",2)),e.push(r(a.fullSummary))),"keyMoments"in a&&a.keyMoments&&a.keyMoments.length>0&&(e.push(s()),e.push(n("주요 타임스탬프",2)),a.keyMoments.forEach(o=>e.push(c(`[${o.timestamp}] ${o.description}`)))),e}async function J(t,a){const e=t.result,n="⭐".repeat(e.recommendation.score),r=t.contentType==="youtube"?"🎬":"📄",c=e.mode==="learn"?"학습 모드":"일반 모드";let s="";e.mode==="learn"?s=e.keyTakeaways.map(u=>`• ${u}`).join(`
`):s=e.threeLineSummary.map(u=>`• ${u}`).join(`
`);const i={blocks:[{type:"header",text:{type:"plain_text",text:`${r} ${t.title}`,emoji:!0}},{type:"section",fields:[{type:"mrkdwn",text:`*모드:* ${c}`},{type:"mrkdwn",text:`*추천도:* ${n} (${e.recommendation.score}/5)`}]},{type:"section",text:{type:"mrkdwn",text:`*추천 이유:* ${e.recommendation.reason}`}},{type:"divider"},{type:"section",text:{type:"mrkdwn",text:`*핵심 내용:*
${s}`}},{type:"actions",elements:[{type:"button",text:{type:"plain_text",text:"원문 보기",emoji:!0},url:t.url,action_id:"view_original"}]}]},o=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)});if(!o.ok)throw new Error(`Slack 전송 오류 (${o.status})`)}const A="syl_watch_later",dt=240;async function M(){const t=await chrome.storage.local.get(A),a={...nt,...t[A]??{}},e=new Date().toISOString().slice(0,10);return a.dailyResetDate!==e&&(a.dailyRequestCount=0,a.dailyResetDate=e),a}async function K(t){await chrome.storage.local.set({[A]:t})}async function _(){const t=await M();t.dailyRequestCount++,await K(t)}function ht(t){return t.dailyRequestCount<dt}async function mt(){try{const t=await fetch("https://www.youtube.com/playlist?list=WL",{credentials:"include",headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!t.ok)return[];const a=await t.text();return pt(a)}catch{return[]}}function pt(t){var n,r,c,s,i,o,u,d,h,p,l,m,w,f,O,R,$;const a=[],e=t.match(/var\s+ytInitialData\s*=\s*({.+?});\s*<\/script>/s);if(!e)return a;try{const T=JSON.parse(e[1]),N=(w=(m=(l=(p=(h=(d=(u=(o=(i=(s=(c=(r=(n=T==null?void 0:T.contents)==null?void 0:n.twoColumnBrowseResultsRenderer)==null?void 0:r.tabs)==null?void 0:c[0])==null?void 0:s.tabRenderer)==null?void 0:i.content)==null?void 0:o.sectionListRenderer)==null?void 0:u.contents)==null?void 0:d[0])==null?void 0:h.itemSectionRenderer)==null?void 0:p.contents)==null?void 0:l[0])==null?void 0:m.playlistVideoListRenderer)==null?void 0:w.contents;if(!Array.isArray(N))return a;for(const k of N){const g=k==null?void 0:k.playlistVideoRenderer;if(!g)continue;const E=g.videoId,X=((R=(O=(f=g.title)==null?void 0:f.runs)==null?void 0:O[0])==null?void 0:R.text)??(($=g.title)==null?void 0:$.simpleText)??"제목 없음";E&&typeof E=="string"&&a.push({videoId:E,title:X})}}catch{return a}return a}const yt=["chrome://","chrome-extension://","about:","edge://","devtools://"],ft=["accounts.google.com","chromewebstore.google.com","chrome.google.com"],L="watch-later-sync";chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});chrome.runtime.onMessage.addListener((t,a,e)=>(wt(t,e),!0));chrome.alarms.onAlarm.addListener(t=>{t.name===L&&q().catch(a=>{console.error("Watch Later sync failed:",a)})});chrome.runtime.onInstalled.addListener(()=>{x()});chrome.runtime.onStartup.addListener(()=>{x()});async function x(){const t=await y();await chrome.alarms.clear(L),t.watchLaterEnabled&&chrome.alarms.create(L,{periodInMinutes:t.watchLaterInterval})}async function wt(t,a){try{switch(t.type){case"EXTRACT_AND_SUMMARIZE":{const{mode:e}=t.payload,n=await Tt(e);a({success:!0,data:n});break}case"SUMMARIZE":{const{content:e,mode:n}=t.payload,r=await V(e,n);a({success:!0,data:r});break}case"GET_SETTINGS":{const e=await y();a({success:!0,data:e});break}case"SAVE_SETTINGS":{const e=t.payload;await rt(e),await x(),a({success:!0});break}case"GET_HISTORY":{const e=await G();a({success:!0,data:e});break}case"CLEAR_HISTORY":{await st(),a({success:!0});break}case"EXPORT_NOTION":{const{item:e}=t.payload,n=await y();if(!n.notionToken||!n.notionDatabaseId){a({success:!1,error:"Notion 설정이 완료되지 않았습니다."});break}const r=await F(e,n.notionToken,n.notionDatabaseId);a({success:!0,data:{url:r}});break}case"EXPORT_SLACK":{const{item:e}=t.payload,n=await y();if(!n.slackWebhookUrl){a({success:!1,error:"Slack Webhook URL이 설정되지 않았습니다."});break}await J(e,n.slackWebhookUrl),a({success:!0});break}case"SYNC_WATCH_LATER":{q().then(e=>a({success:!0,data:{count:e}})).catch(e=>a({success:!1,error:e.message}));return}case"GET_WATCH_LATER_STATUS":{const e=await M();a({success:!0,data:e});break}default:a({success:!1,error:"알 수 없는 메시지 타입"})}}catch(e){const n=e instanceof Error?e.message:"알 수 없는 오류가 발생했습니다.";a({success:!1,error:n})}}function gt(t){if(yt.some(a=>t.startsWith(a)))return!0;try{const a=new URL(t);return ft.includes(a.hostname)}catch{return!0}}async function St(t){try{await chrome.scripting.executeScript({target:{tabId:t},files:["content/extractor.js"]})}catch{}return await new Promise(a=>setTimeout(a,150)),new Promise((a,e)=>{chrome.tabs.sendMessage(t,{type:"EXTRACT_CONTENT"},n=>{if(chrome.runtime.lastError){e(new Error("페이지와 통신할 수 없습니다. 페이지를 새로고침 후 다시 시도해주세요."));return}if(!(n!=null&&n.success)||!n.data){e(new Error((n==null?void 0:n.error)??"페이지 내용을 추출할 수 없습니다."));return}a(n.data)})})}async function Tt(t){const e=(await chrome.tabs.query({active:!0,lastFocusedWindow:!0}))[0];if(!(e!=null&&e.id)||!e.url)throw new Error("현재 탭을 찾을 수 없습니다. 웹 페이지를 열고 다시 시도해주세요.");if(gt(e.url))throw new Error("이 페이지에서는 요약할 수 없습니다. 일반 웹 페이지나 유튜브에서 사용해주세요.");const n=await St(e.id);if(n.type==="webpage"&&!n.text)throw new Error("이 페이지에서 요약할 콘텐츠를 찾을 수 없습니다. 기사나 블로그 같은 텍스트가 있는 페이지에서 사용해주세요.");return V(n,t)}async function V(t,a){const e=await y();if(!e.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다. 설정 탭에서 입력해주세요.");let n=t;if(t.type==="youtube"&&!t.text&&t.videoId){const s=await H(t.videoId);if(s&&s.segments.length>0)n={...t,text:B(s.segments),hasSubtitles:!0};else{await _();const i=await j(t,a,e.geminiApiKey),o={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:t.url,title:t.title,contentType:t.type,mode:a,result:i,createdAt:Date.now()};return await I(o),{result:i,historyItem:o}}}await _();const r=await W(n,a,e.geminiApiKey),c={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:t.url,title:t.title,contentType:t.type,mode:a,result:r,createdAt:Date.now()};return await I(c),{result:r,historyItem:c}}async function q(){const t=await y();if(!t.watchLaterEnabled||!t.geminiApiKey||t.watchLaterAutoExport==="none")return 0;const a=t.watchLaterAutoExport!=="notion"&&!!t.slackWebhookUrl,e=t.watchLaterAutoExport!=="slack"&&!!t.notionToken&&!!t.notionDatabaseId;if(!a&&!e)return 0;const n=await M(),r=await mt();if(r.length===0)return 0;const c=n.processedVideoIds.length===0?r:r.filter(i=>!n.processedVideoIds.includes(i.videoId));if(c.length===0)return 0;let s=0;for(const i of c){if(!ht(n))break;try{const o={type:"youtube",title:i.title,text:"",url:`https://www.youtube.com/watch?v=${i.videoId}`,videoId:i.videoId},u=await H(i.videoId);let d;u&&u.segments.length>0?(o.text=B(u.segments),o.hasSubtitles=!0,d=await W(o,t.defaultMode,t.geminiApiKey)):d=await j(o,t.defaultMode,t.geminiApiKey),await _();const h={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:o.url,title:i.title,contentType:"youtube",mode:t.defaultMode,result:d,createdAt:Date.now()};await I(h),a&&await J(h,t.slackWebhookUrl).catch(()=>{}),e&&await F(h,t.notionToken,t.notionDatabaseId).catch(()=>{}),n.processedVideoIds.push(i.videoId),s++,await new Promise(p=>setTimeout(p,6500))}catch{continue}}if(n.lastCheckedAt=Date.now(),n.processedVideoIds.length>500&&(n.processedVideoIds=n.processedVideoIds.slice(-500)),await K(n),s>0){const i=a&&e?"Slack과 Notion":a?"Slack":"Notion";chrome.notifications.create({type:"basic",iconUrl:chrome.runtime.getURL("icons/icon-128.png"),title:"See You Later",message:`${s}개의 새 영상 요약이 ${i}으로 전송되었습니다.`})}return s}
