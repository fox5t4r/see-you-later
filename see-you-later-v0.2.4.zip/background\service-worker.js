const $=`당신은 냉철하고 까다로운 콘텐츠 분석 전문가입니다. 사용자가 웹에서 발견한 글이나 영상의 내용을 분석하여, 사용자의 시간을 절약하고 핵심 가치를 전달하는 것이 목표입니다.

규칙:
1. 모든 응답은 한국어로 작성합니다. 단, 고유명사와 기술 용어는 원문 그대로 유지합니다.
2. 반드시 지정된 JSON 형식으로만 응답합니다. JSON 외의 텍스트는 절대 포함하지 않습니다.
3. JSON 키는 영어로, 값은 한국어로 작성합니다.
4. 추천도 점수는 냉정하게 평가합니다. 대부분의 콘텐츠는 2~3점이어야 합니다.
   - 5점: 해당 분야의 필독/필시청. 독창적 통찰, 실질적 가치가 탁월. 상위 5% 수준만 해당
   - 4점: 꽤 좋음. 새로운 관점이나 깊이 있는 분석이 있음. 상위 20% 수준
   - 3점: 평균. 읽으면 얻는 것이 있지만 특별하지는 않음. 대부분의 콘텐츠가 여기 해당
   - 2점: 평균 이하. 이미 알려진 정보 반복, 깊이 부족, 시간 대비 가치 낮음
   - 1점: 스킵 권장. 낚시성 제목, 내용 빈약, 광고성, 오류 다수
   4~5점을 남발하지 마세요. 정말 뛰어난 콘텐츠에만 4점 이상을 부여하세요.`,L=`다음 웹 페이지 내용을 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "coreConcepts": [
    {
      "concept": "핵심 개념 이름",
      "explanation": "이 개념이 무엇인지 초보자도 이해할 수 있게 설명",
      "whyItMatters": "왜 이것이 중요한지"
    }
  ],
  "keyTakeaways": [
    "배울 점 1 - 구체적으로 어떻게 적용할 수 있는지 포함",
    "배울 점 2",
    "배울 점 3"
  ],
  "backgroundContext": "이 내용을 더 잘 이해하기 위해 알면 좋은 배경지식",
  "practicalApplication": "실제로 이 지식을 어떻게 활용할 수 있는지",
  "furtherLearning": "더 깊이 알고 싶다면 찾아볼 키워드나 주제",
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵해도 됨",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 글은 2~3점입니다. 4점 이상은 정말 뛰어난 글에만 부여하세요.

웹 페이지 내용:`,M=`다음 유튜브 영상의 자막/트랜스크립트를 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "videoTitle": "영상 제목 (자막에서 추론)",
  "coreConcepts": [
    {
      "concept": "핵심 개념",
      "explanation": "친절한 설명",
      "timestamp": "MM:SS (해당 내용이 나오는 시점, 없으면 null)"
    }
  ],
  "keyTakeaways": ["배울 점 1", "배울 점 2", "배울 점 3"],
  "backgroundContext": "배경지식",
  "practicalApplication": "실제 활용법",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "이 시점에서 다루는 내용" }
  ],
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": false,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": true,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 영상은 2~3점입니다. 4점 이상은 정말 뛰어난 영상에만 부여하세요.

유튜브 자막/트랜스크립트:`,R=`다음 웹 페이지 내용을 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": [
    "핵심 내용 첫 번째 줄",
    "핵심 내용 두 번째 줄",
    "핵심 내용 세 번째 줄"
  ],
  "fullSummary": "전체 내용을 읽지 않아도 맥락을 완전히 이해할 수 있는 상세 요약. 글의 주장, 근거, 결론을 모두 포함하여 3~5 문단으로 작성.",
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 글은 2~3점입니다. 4점 이상은 정말 뛰어난 글에만 부여하세요.

웹 페이지 내용:`,N=`다음 유튜브 영상의 자막/트랜스크립트를 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": ["첫 번째 줄", "두 번째 줄", "세 번째 줄"],
  "fullSummary": "영상 전체 내용의 상세 요약. 3~5 문단.",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "주요 포인트" }
  ],
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": false,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": true,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 영상은 2~3점입니다. 4점 이상은 정말 뛰어난 영상에만 부여하세요.

유튜브 자막/트랜스크립트:`,V="https://generativelanguage.googleapis.com/v1beta/models",J="gemini-2.5-pro";function q(n,e){const t=n.text.length>6e4?n.text.slice(0,6e4)+`

[내용이 너무 길어 일부 생략됨]`:n.text;return e==="learn"?`${n.type==="youtube"?M:L}

제목: ${n.title}
URL: ${n.url}

${t}`:`${n.type==="youtube"?N:R}

제목: ${n.title}
URL: ${n.url}

${t}`}function X(n,e){return e==="learn"?n.type==="youtube"?M:L:n.type==="youtube"?N:R}async function O(n,e,t){const s={contents:[{parts:[{text:q(n,e)}]}],systemInstruction:{parts:[{text:$}]},generationConfig:{maxOutputTokens:4096,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:128}}};return v(s,t)}async function C(n,e,t){const o=n.url,s=X(n,e)+`

제목: ${n.title}
URL: ${o}`;return v({contents:[{parts:[{fileData:{mimeType:"video/mp4",fileUri:o}},{text:s}]}],systemInstruction:{parts:[{text:$}]},generationConfig:{maxOutputTokens:4096,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:128}}},t)}async function v(n,e){var a,c,l,u,m,h;const t=`${V}/${J}:generateContent?key=${e}`,o=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(n)});if(!o.ok){const j=await o.json().catch(()=>({error:{message:"알 수 없는 오류"}})),g=o.status;throw g===429?new Error("API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."):g===403?new Error("API 키가 유효하지 않습니다. 설정에서 Gemini API 키를 확인해주세요."):new Error(`Gemini API 오류 (${g}): ${((a=j.error)==null?void 0:a.message)??"요청 실패"}`)}const s=await o.json(),i=((u=(l=(c=s.candidates)==null?void 0:c[0])==null?void 0:l.content)==null?void 0:u.parts)??[],r=i.filter(y=>!y.thought&&y.text).pop(),d=(r==null?void 0:r.text)??"";if(!d)throw((h=(m=s.candidates)==null?void 0:m[0])==null?void 0:h.finishReason)==="SAFETY"?new Error("안전 필터에 의해 응답이 차단되었습니다. 다른 콘텐츠로 시도해주세요."):(console.error("[See You Later] Empty Gemini response. Parts:",JSON.stringify(i).slice(0,500)),new Error("AI 응답이 비어있습니다. 다시 시도해주세요."));return z(d)}function z(n){try{return JSON.parse(n.trim())}catch{}const e=n.match(/```(?:json)?\s*([\s\S]*?)```/);if(e)try{return JSON.parse(e[1].trim())}catch{}const t=n.indexOf("{"),o=n.lastIndexOf("}");if(t!==-1&&o>t)try{return JSON.parse(n.slice(t,o+1))}catch{}throw console.error("[See You Later] Failed to parse response:",n.slice(0,500)),new Error("AI 응답을 파싱할 수 없습니다. 다시 시도해주세요.")}const Z={defaultMode:"summary",geminiApiKey:"",notionToken:"",notionDatabaseId:"",slackWebhookUrl:"",summaryLanguage:"ko",watchLaterEnabled:!1,watchLaterInterval:60,watchLaterAutoExport:"none"},Q={processedVideoIds:[],lastCheckedAt:0,dailyRequestCount:0,dailyResetDate:""},w="syl_history",k="syl_settings",tt=50;async function p(){const n=await chrome.storage.local.get(k);return{...Z,...n[k]??{}}}async function et(n){const e=await p();await chrome.storage.local.set({[k]:{...e,...n}})}async function D(){return(await chrome.storage.local.get(w))[w]??[]}async function S(n){const e=await D(),t=[n,...e].slice(0,tt);await chrome.storage.local.set({[w]:t})}async function nt(){await chrome.storage.local.remove(w)}async function P(n){var e,t;try{const o=await fetch(`https://www.youtube.com/watch?v=${n}`,{headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!o.ok)return null;const i=(await o.text()).match(/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/);if(!i)return null;const r=JSON.parse(i[1]),d=(t=(e=r==null?void 0:r.captions)==null?void 0:e.playerCaptionsTracklistRenderer)==null?void 0:t.captionTracks;if(!d||d.length===0)return null;const a=ot(d);if(!a)return null;const c=a.baseUrl+"&fmt=json3",l=await fetch(c);return l.ok?{segments:((await l.json()).events??[]).filter(h=>h.segs&&h.tStartMs!==void 0).map(h=>({text:(h.segs??[]).map(y=>y.utf8??"").join("").replace(/\n/g," ").trim(),start:(h.tStartMs??0)/1e3,duration:(h.dDurationMs??0)/1e3})).filter(h=>h.text.length>0),language:a.languageCode,isAutoGenerated:a.kind==="asr"}:null}catch{return null}}function ot(n){const e=[t=>t.languageCode==="ko"&&t.kind!=="asr",t=>t.languageCode.startsWith("en")&&t.kind!=="asr",t=>t.languageCode==="ko",t=>t.languageCode.startsWith("en"),()=>!0];for(const t of e){const o=n.find(t);if(o)return o}return null}function U(n){return n.map(e=>{const t=Math.floor(e.start/60),o=Math.floor(e.start%60);return`[${`${String(t).padStart(2,"0")}:${String(o).padStart(2,"0")}`}] ${e.text}`}).join(`
`)}const W="https://api.notion.com/v1",G="2022-06-28";async function F(n,e,t){const o=t.replace(/-/g,""),i=await at(o,e)?{database_id:o}:{page_id:o},r=rt(n),d={parent:i,properties:{title:{title:[{text:{content:n.title.slice(0,2e3)}}]}},children:r},a=await fetch(`${W}/pages`,{method:"POST",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json","Notion-Version":G},body:JSON.stringify(d)});if(!a.ok){const l=await a.json().catch(()=>({}));throw a.status===403||l.code==="restricted_resource"?new Error(`Notion 접근 권한 없음
저장할 페이지 우측 상단 ··· → 연결 → Integration 선택`):a.status===404?new Error(`Notion 페이지를 찾을 수 없습니다.
설정의 Page ID가 올바른지 확인해주세요.`):new Error(`Notion 저장 오류 (${a.status}): ${l.message??"요청 실패"}`)}const c=await a.json();return c.url??`https://notion.so/${c.id.replace(/-/g,"")}`}async function at(n,e){try{return(await fetch(`${W}/databases/${n}`,{headers:{Authorization:`Bearer ${e}`,"Notion-Version":G}})).ok}catch{return!1}}function T(n,e=2e3){return[{text:{content:n.slice(0,e)}}]}function rt(n){const e=n.result,t=[],o=(u,m)=>({type:`heading_${m}`,[`heading_${m}`]:{rich_text:T(u)}}),s=u=>({type:"paragraph",paragraph:{rich_text:T(u)}}),i=u=>({type:"bulleted_list_item",bulleted_list_item:{rich_text:T(u)}}),r=()=>({type:"divider",divider:{}}),d=n.contentType==="youtube"?"🎬 유튜브":"📄 웹 페이지",a=e.mode==="learn"?"학습 모드":"일반 모드",c=new Date(n.createdAt).toLocaleString("ko-KR"),l="⭐".repeat(e.recommendation.score);if(t.push(s(`${d} | ${a} | ${c}`)),t.push(s(`🔗 ${n.url}`)),t.push(r()),t.push(o("추천도",2)),t.push(s(`${l} (${e.recommendation.score}/5)  ${e.recommendation.reason}`)),t.push(s(`✅ 추천 대상: ${e.recommendation.bestFor}`)),t.push(s(`⏭️ 스킵 대상: ${e.recommendation.skipIf}`)),t.push(r()),e.mode==="learn")t.push(o("핵심 개념",2)),e.coreConcepts.forEach(u=>{t.push(o(u.concept,3)),t.push(s(u.explanation)),u.whyItMatters&&t.push(s(`💡 ${u.whyItMatters}`))}),t.push(r()),t.push(o("배울 점",2)),e.keyTakeaways.forEach(u=>t.push(i(u))),t.push(r()),t.push(o("실제 적용",2)),t.push(s(e.practicalApplication)),t.push(o("배경 지식",2)),t.push(s(e.backgroundContext)),e.furtherLearning&&(t.push(o("더 알아보기",2)),t.push(s(e.furtherLearning)));else{t.push(o("3줄 요약",2)),e.threeLineSummary.forEach(h=>t.push(i(h))),t.push(r()),t.push(o("전체 요약",2));const u=e.fullSummary,m=1900;for(let h=0;h<u.length;h+=m)t.push(s(u.slice(h,h+m)))}return"keyMoments"in e&&e.keyMoments&&e.keyMoments.length>0&&(t.push(r()),t.push(o("주요 타임스탬프",2)),e.keyMoments.forEach(u=>t.push(i(`[${u.timestamp}] ${u.description}`)))),t.slice(0,100)}const st=2900;function f(n,e=st){return n.length>e?n.slice(0,e)+"...":n}async function Y(n,e){const t=n.result,o="⭐".repeat(t.recommendation.score),s=n.contentType==="youtube"?"🎬":"📄",i=t.mode==="learn"?"학습 모드":"일반 모드",r=[{type:"header",text:{type:"plain_text",text:`${s} ${n.title}`.slice(0,150),emoji:!0}},{type:"section",fields:[{type:"mrkdwn",text:`*모드:* ${i}`},{type:"mrkdwn",text:`*추천도:* ${o} (${t.recommendation.score}/5)`}]},{type:"section",text:{type:"mrkdwn",text:`*추천 이유:* ${t.recommendation.reason}`}},{type:"section",fields:[{type:"mrkdwn",text:`*✅ 추천 대상:* ${t.recommendation.bestFor}`},{type:"mrkdwn",text:`*⏭️ 스킵 대상:* ${t.recommendation.skipIf}`}]}];if("worthWatching"in t.recommendation&&t.recommendation.worthWatching!==void 0){const a=t.recommendation.worthWatching?"🎬 직접 시청 권장":"📄 요약으로 충분",c=t.recommendation.worthWatchingReason?`: ${t.recommendation.worthWatchingReason}`:"";r.push({type:"section",text:{type:"mrkdwn",text:`*${a}*${c}`}})}if("worthFullRead"in t.recommendation&&t.recommendation.worthFullRead!==void 0){const a=t.recommendation.worthFullRead?"📖 전문 읽기 권장":"📄 요약으로 충분",c=t.recommendation.worthFullReadReason?`: ${t.recommendation.worthFullReadReason}`:"";r.push({type:"section",text:{type:"mrkdwn",text:`*${a}*${c}`}})}if(r.push({type:"divider"}),t.mode==="learn"){const a=t.coreConcepts.map(l=>`*${l.concept}*
${l.explanation}`).join(`

`);r.push({type:"section",text:{type:"mrkdwn",text:`*핵심 개념:*
${f(a)}`}});const c=t.keyTakeaways.map(l=>`• ${l}`).join(`
`);r.push({type:"section",text:{type:"mrkdwn",text:`*배울 점:*
${f(c)}`}}),r.push({type:"section",text:{type:"mrkdwn",text:`*실제 적용:*
${f(t.practicalApplication)}`}})}else{const a=t.threeLineSummary.map(c=>`• ${c}`).join(`
`);r.push({type:"section",text:{type:"mrkdwn",text:`*3줄 요약:*
${a}`}}),r.push({type:"divider"}),r.push({type:"section",text:{type:"mrkdwn",text:`*전체 요약:*
${f(t.fullSummary)}`}})}if("keyMoments"in t&&t.keyMoments&&t.keyMoments.length>0){const a=t.keyMoments.map(c=>`• \`[${c.timestamp}]\` ${c.description}`).join(`
`);r.push({type:"divider"}),r.push({type:"section",text:{type:"mrkdwn",text:`*주요 타임스탬프:*
${f(a,1500)}`}})}r.push({type:"actions",elements:[{type:"button",text:{type:"plain_text",text:"원문 보기",emoji:!0},url:n.url,action_id:"view_original"}]});const d=await fetch(e,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({blocks:r})});if(!d.ok)throw new Error(`Slack 전송 오류 (${d.status})`)}const b="syl_watch_later",it=240,ct="https://www.youtube.com/playlist?list=WL",ut=3;async function I(){const n=await chrome.storage.local.get(b),e={...Q,...n[b]??{}},t=new Date().toISOString().slice(0,10);return e.dailyResetDate!==t&&(e.dailyRequestCount=0,e.dailyResetDate=t),e}async function B(n){await chrome.storage.local.set({[b]:n})}async function E(){const n=await I();n.dailyRequestCount++,await B(n)}function lt(n){return n.dailyRequestCount<it}async function dt(){var t;let n=null,e=!1;try{const o=await chrome.tabs.query({url:"*://www.youtube.com/playlist?list=WL*"});if(o.length>0&&o[0].id!=null)n=o[0].id,await chrome.tabs.reload(n),await x(n);else{if(n=(await chrome.tabs.create({url:ct,active:!1})).id??null,e=!0,n==null)return[];await x(n)}for(let s=0;s<ut;s++){const i=await chrome.scripting.executeScript({target:{tabId:n},func:mt}),r=(t=i==null?void 0:i[0])==null?void 0:t.result;if(r&&r.length>0)return r;await ht((s+1)*2e3)}return[]}catch(o){return console.error("[See You Later] Watch Later fetch failed:",o),[]}finally{e&&n!=null&&chrome.tabs.remove(n).catch(()=>{})}}function ht(n){return new Promise(e=>setTimeout(e,n))}function x(n){return new Promise(e=>{const t=setTimeout(()=>{chrome.tabs.onUpdated.removeListener(o),e()},15e3);function o(s,i){s===n&&i.status==="complete"&&(clearTimeout(t),chrome.tabs.onUpdated.removeListener(o),setTimeout(e,3e3))}chrome.tabs.onUpdated.addListener(o)})}function mt(){var s;const n=new Set,e=[];function t(i,r){i&&!n.has(i)&&(n.add(i),e.push({videoId:i,title:r||"제목 없음"}))}try{const i=document.querySelectorAll("ytd-playlist-video-renderer");for(const d of i){const a=d.querySelector('a#video-title, a.yt-simple-endpoint[href*="/watch"]');if(!a)continue;const l=(a.href||a.getAttribute("href")||"").match(/[?&]v=([a-zA-Z0-9_-]{11})/);l&&t(l[1],(a.textContent??"").trim())}if(e.length>0)return e;const r=document.querySelector('#contents, ytd-playlist-video-list-renderer, [id="playlist-items"]');if(r){const d=r.querySelectorAll('a[href*="/watch?v="]');for(const a of d){const l=(a.href||"").match(/[?&]v=([a-zA-Z0-9_-]{11})/);if(l){const u=((s=a.textContent)==null?void 0:s.trim())||a.getAttribute("title")||"";u.length>1&&t(l[1],u)}}}if(e.length>0)return e}catch{}try{const i=window.ytInitialData;if(i&&typeof i=="object"&&o(i),e.length>0)return e}catch{}try{const i=document.querySelectorAll("script");for(const r of i){const d=r.textContent??"";if(!d.includes("ytInitialData"))continue;const a=d.match(/var\s+ytInitialData\s*=\s*(\{.+?\});\s*(?:<\/script>|$)/s);if(a){const c=JSON.parse(a[1]);if(o(c),e.length>0)return e}}}catch{}return e;function o(i){var d;if(!i||typeof i!="object")return;if(Array.isArray(i)){for(const a of i)o(a);return}const r=i;if(r.playlistVideoRenderer){const a=r.playlistVideoRenderer,c=a.videoId;if(c){const l=a.title,u=l==null?void 0:l.runs,m=l==null?void 0:l.simpleText;t(c,((d=u==null?void 0:u[0])==null?void 0:d.text)??m??"제목 없음");return}}for(const a of Object.keys(r))a==="thumbnail"||a==="playerOverlays"||a==="engagementPanels"||o(r[a])}}const pt=["chrome://","chrome-extension://","about:","edge://","devtools://"],yt=["accounts.google.com","chromewebstore.google.com","chrome.google.com"],A="watch-later-sync";chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});chrome.runtime.onMessage.addListener((n,e,t)=>(ft(n,t),!0));chrome.alarms.onAlarm.addListener(n=>{n.name===A&&K({manual:!1}).catch(e=>{console.error("Watch Later sync failed:",e)})});chrome.runtime.onInstalled.addListener(()=>{_()});chrome.runtime.onStartup.addListener(()=>{_()});async function _(){const n=await p();await chrome.alarms.clear(A),n.watchLaterEnabled&&chrome.alarms.create(A,{periodInMinutes:n.watchLaterInterval})}async function ft(n,e){try{switch(n.type){case"EXTRACT_AND_SUMMARIZE":{const{mode:t}=n.payload,o=await Tt(t);e({success:!0,data:o});break}case"SUMMARIZE":{const{content:t,mode:o}=n.payload,s=await H(t,o);e({success:!0,data:s});break}case"GET_SETTINGS":{const t=await p();e({success:!0,data:t});break}case"SAVE_SETTINGS":{const t=n.payload;await et(t),await _(),e({success:!0});break}case"GET_HISTORY":{const t=await D();e({success:!0,data:t});break}case"CLEAR_HISTORY":{await nt(),e({success:!0});break}case"EXPORT_NOTION":{const{item:t}=n.payload,o=await p();if(!o.notionToken||!o.notionDatabaseId){e({success:!1,error:"Notion 설정이 완료되지 않았습니다."});break}const s=await F(t,o.notionToken,o.notionDatabaseId);e({success:!0,data:{url:s}});break}case"EXPORT_SLACK":{const{item:t}=n.payload,o=await p();if(!o.slackWebhookUrl){e({success:!1,error:"Slack Webhook URL이 설정되지 않았습니다."});break}await Y(t,o.slackWebhookUrl),e({success:!0});break}case"SYNC_WATCH_LATER":{K({manual:!0}).then(t=>e({success:!0,data:{count:t}})).catch(t=>e({success:!1,error:t.message}));return}case"GET_WATCH_LATER_STATUS":{const t=await I();e({success:!0,data:t});break}default:e({success:!1,error:"알 수 없는 메시지 타입"})}}catch(t){const o=t instanceof Error?t.message:"알 수 없는 오류가 발생했습니다.";e({success:!1,error:o})}}function wt(n){if(pt.some(e=>n.startsWith(e)))return!0;try{const e=new URL(n);return yt.includes(e.hostname)}catch{return!0}}async function gt(n){try{await chrome.scripting.executeScript({target:{tabId:n},files:["content/extractor.js"]})}catch{}return await new Promise(e=>setTimeout(e,150)),new Promise((e,t)=>{chrome.tabs.sendMessage(n,{type:"EXTRACT_CONTENT"},o=>{if(chrome.runtime.lastError){t(new Error("페이지와 통신할 수 없습니다. 페이지를 새로고침 후 다시 시도해주세요."));return}if(!(o!=null&&o.success)||!o.data){t(new Error((o==null?void 0:o.error)??"페이지 내용을 추출할 수 없습니다."));return}e(o.data)})})}async function Tt(n){const t=(await chrome.tabs.query({active:!0,lastFocusedWindow:!0}))[0];if(!(t!=null&&t.id)||!t.url)throw new Error("현재 탭을 찾을 수 없습니다. 웹 페이지를 열고 다시 시도해주세요.");if(wt(t.url))throw new Error("이 페이지에서는 요약할 수 없습니다. 일반 웹 페이지나 유튜브에서 사용해주세요.");const o=await gt(t.id);if(o.type==="webpage"&&!o.text)throw new Error("이 페이지에서 요약할 콘텐츠를 찾을 수 없습니다. 기사나 블로그 같은 텍스트가 있는 페이지에서 사용해주세요.");return H(o,n)}async function H(n,e){const t=await p();if(!t.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다. 설정 탭에서 입력해주세요.");let o=n;if(n.type==="youtube"&&!n.text&&n.videoId){const r=await P(n.videoId);if(r&&r.segments.length>0)o={...n,text:U(r.segments),hasSubtitles:!0};else{await E();const d=await C(n,e,t.geminiApiKey),a={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:n.url,title:n.title,contentType:n.type,mode:e,result:d,createdAt:Date.now()};return await S(a),{result:d,historyItem:a}}}await E();const s=await O(o,e,t.geminiApiKey),i={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:n.url,title:n.title,contentType:n.type,mode:e,result:s,createdAt:Date.now()};return await S(i),{result:s,historyItem:i}}async function K(n){const e=await p();if(!e.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다.");if(!(n!=null&&n.manual)&&!e.watchLaterEnabled)return 0;const t=(e.watchLaterAutoExport==="slack"||e.watchLaterAutoExport==="both")&&!!e.slackWebhookUrl,o=(e.watchLaterAutoExport==="notion"||e.watchLaterAutoExport==="both")&&!!e.notionToken&&!!e.notionDatabaseId,s=await I(),i=await dt();if(i.length===0)throw new Error(`"나중에 볼 동영상" 목록을 가져올 수 없습니다.
YouTube에 로그인되어 있는지 확인하고, YouTube 탭이 열려 있으면 새로고침 후 다시 시도해주세요.`);const r=s.processedVideoIds.length===0?i:i.filter(a=>!s.processedVideoIds.includes(a.videoId));if(r.length===0)return 0;let d=0;for(const a of r){if(!lt(s))break;try{const c={type:"youtube",title:a.title,text:"",url:`https://www.youtube.com/watch?v=${a.videoId}`,videoId:a.videoId},l=await P(a.videoId);let u;l&&l.segments.length>0?(c.text=U(l.segments),c.hasSubtitles=!0,u=await O(c,e.defaultMode,e.geminiApiKey)):u=await C(c,e.defaultMode,e.geminiApiKey),await E();const m={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:c.url,title:a.title,contentType:"youtube",mode:e.defaultMode,result:u,createdAt:Date.now()};await S(m),t&&await Y(m,e.slackWebhookUrl).catch(()=>{}),o&&await F(m,e.notionToken,e.notionDatabaseId).catch(()=>{}),s.processedVideoIds.push(a.videoId),d++,await new Promise(h=>setTimeout(h,6500))}catch{continue}}if(s.lastCheckedAt=Date.now(),s.processedVideoIds.length>500&&(s.processedVideoIds=s.processedVideoIds.slice(-500)),await B(s),d>0){const a=t&&o?"Slack과 Notion":t?"Slack":"Notion";chrome.notifications.create({type:"basic",iconUrl:chrome.runtime.getURL("icons/icon-128.png"),title:"See You Later",message:`${d}개의 새 영상 요약이 ${a}으로 전송되었습니다.`})}return d}
