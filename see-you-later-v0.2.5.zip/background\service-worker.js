const N=`당신은 냉철하고 까다로운 콘텐츠 분석 전문가입니다. 사용자가 웹에서 발견한 글이나 영상의 내용을 분석하여, 사용자의 시간을 절약하고 핵심 가치를 전달하는 것이 목표입니다.

규칙:
1. 모든 응답은 한국어로 작성합니다. 단, 고유명사와 기술 용어는 원문 그대로 유지합니다.
2. 반드시 지정된 JSON 형식으로만 응답합니다. JSON 외의 텍스트는 절대 포함하지 않습니다.
3. JSON 키는 영어로, 값은 한국어로 작성합니다.
4. 추천도 점수는 냉정하게 평가합니다. 대부분의 콘텐츠는 2~3점이어야 합니다.
   - 5점: 해당 분야의 필독/필시청. 독창적 통찰, 실질적 가치가 탁월. 상위 5% 수준만 해당
   - 4점: 꽤 좋음. 새로운 관점이나 깊이 있는 분석이 있음. 상위 20% 수준
   - 3점: 평균. 읽으면 얻는 것이 있지만 특별하지는 않음. 대부분의 콘텐츠가 여기 해당
   - 2점: 평균 이하. 이미 알려진 정보 반복, 깊이 부족, 시간 대비 가치 낮음
   - 1점: 스킵 권장. 낚시성 제목, 내용 빈약, 광고성, 오류 다수
   4~5점을 남발하지 마세요. 정말 뛰어난 콘텐츠에만 4점 이상을 부여하세요.`,O=`다음 웹 페이지 내용을 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "coreConcepts": [
    {
      "concept": "핵심 개념 이름",
      "explanation": "이 개념이 무엇인지 초보자도 이해할 수 있게 설명",
      "whyItMatters": "왜 이것이 중요한지"
    }
  ],
  "keyTakeaways": [
    "배울 점 1 - 구체적으로 어떻게 적용할 수 있는지 포함",
    "배울 점 2",
    "배울 점 3"
  ],
  "backgroundContext": "이 내용을 더 잘 이해하기 위해 알면 좋은 배경지식",
  "practicalApplication": "실제로 이 지식을 어떻게 활용할 수 있는지",
  "furtherLearning": "더 깊이 알고 싶다면 찾아볼 키워드나 주제",
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵해도 됨",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 글은 2~3점입니다. 4점 이상은 정말 뛰어난 글에만 부여하세요.

웹 페이지 내용:`,C=`다음 유튜브 영상의 자막/트랜스크립트를 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "videoTitle": "영상 제목 (자막에서 추론)",
  "coreConcepts": [
    {
      "concept": "핵심 개념",
      "explanation": "친절한 설명",
      "timestamp": "MM:SS (해당 내용이 나오는 시점, 없으면 null)"
    }
  ],
  "keyTakeaways": ["배울 점 1", "배울 점 2", "배울 점 3"],
  "backgroundContext": "배경지식",
  "practicalApplication": "실제 활용법",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "이 시점에서 다루는 내용" }
  ],
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": false,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": true,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 영상은 2~3점입니다. 4점 이상은 정말 뛰어난 영상에만 부여하세요.

유튜브 자막/트랜스크립트:`,v=`다음 웹 페이지 내용을 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": [
    "핵심 내용 첫 번째 줄",
    "핵심 내용 두 번째 줄",
    "핵심 내용 세 번째 줄"
  ],
  "fullSummary": "전체 내용을 읽지 않아도 맥락을 완전히 이해할 수 있는 상세 요약. 글의 주장, 근거, 결론을 모두 포함하여 3~5 문단으로 작성.",
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 글은 2~3점입니다. 4점 이상은 정말 뛰어난 글에만 부여하세요.

웹 페이지 내용:`,D=`다음 유튜브 영상의 자막/트랜스크립트를 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": ["첫 번째 줄", "두 번째 줄", "세 번째 줄"],
  "fullSummary": "영상 전체 내용의 상세 요약. 3~5 문단.",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "주요 포인트" }
  ],
  "recommendation": {
    "score": 2,
    "reason": "냉정하고 솔직한 추천 이유 (좋은 점과 아쉬운 점을 균형 있게)",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": false,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": true,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

score는 냉정하게 평가하세요. 평범한 영상은 2~3점입니다. 4점 이상은 정말 뛰어난 영상에만 부여하세요.

유튜브 자막/트랜스크립트:`,X="https://generativelanguage.googleapis.com/v1beta/models",z="gemini-2.5-pro";function Z(e,a){const t=e.text.length>6e4?e.text.slice(0,6e4)+`

[내용이 너무 길어 일부 생략됨]`:e.text;return a==="learn"?`${e.type==="youtube"?C:O}

제목: ${e.title}
URL: ${e.url}

${t}`:`${e.type==="youtube"?D:v}

제목: ${e.title}
URL: ${e.url}

${t}`}function Q(e,a){return a==="learn"?e.type==="youtube"?C:O:e.type==="youtube"?D:v}async function P(e,a,t){const i={contents:[{parts:[{text:Z(e,a)}]}],systemInstruction:{parts:[{text:N}]},generationConfig:{maxOutputTokens:4096,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:128}}};return W(i,t)}async function U(e,a,t){const n=e.url,i=Q(e,a)+`

제목: ${e.title}
URL: ${n}`;return W({contents:[{parts:[{fileData:{mimeType:"video/mp4",fileUri:n}},{text:i}]}],systemInstruction:{parts:[{text:N}]},generationConfig:{maxOutputTokens:4096,responseMimeType:"application/json",thinkingConfig:{thinkingBudget:128}}},t)}async function W(e,a){var r,c,u,l,p,h;const t=`${X}/${z}:generateContent?key=${a}`,n=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)});if(!n.ok){const f=await n.json().catch(()=>({error:{message:"알 수 없는 오류"}})),y=n.status;throw y===429?new Error("API 요청 한도를 초과했습니다. 잠시 후 다시 시도해주세요."):y===403?new Error("API 키가 유효하지 않습니다. 설정에서 Gemini API 키를 확인해주세요."):new Error(`Gemini API 오류 (${y}): ${((r=f.error)==null?void 0:r.message)??"요청 실패"}`)}const i=await n.json(),s=((l=(u=(c=i.candidates)==null?void 0:c[0])==null?void 0:u.content)==null?void 0:l.parts)??[],o=s.filter(m=>!m.thought&&m.text).pop(),d=(o==null?void 0:o.text)??"";if(!d)throw((h=(p=i.candidates)==null?void 0:p[0])==null?void 0:h.finishReason)==="SAFETY"?new Error("안전 필터에 의해 응답이 차단되었습니다. 다른 콘텐츠로 시도해주세요."):(console.error("[See You Later] Empty Gemini response. Parts:",JSON.stringify(s).slice(0,500)),new Error("AI 응답이 비어있습니다. 다시 시도해주세요."));return tt(d)}function tt(e){try{return JSON.parse(e.trim())}catch{}const a=e.match(/```(?:json)?\s*([\s\S]*?)```/);if(a)try{return JSON.parse(a[1].trim())}catch{}const t=e.indexOf("{"),n=e.lastIndexOf("}");if(t!==-1&&n>t)try{return JSON.parse(e.slice(t,n+1))}catch{}throw console.error("[See You Later] Failed to parse response:",e.slice(0,500)),new Error("AI 응답을 파싱할 수 없습니다. 다시 시도해주세요.")}const et={defaultMode:"summary",geminiApiKey:"",notionToken:"",notionDatabaseId:"",slackWebhookUrl:"",summaryLanguage:"ko",watchLaterEnabled:!1,watchLaterInterval:60,watchLaterAutoExport:"none"},at={processedVideoIds:[],lastCheckedAt:0,dailyRequestCount:0,dailyResetDate:""},T="syl_history",A="syl_settings",nt=50;async function w(){const e=await chrome.storage.local.get(A);return{...et,...e[A]??{}}}async function ot(e){const a=await w();await chrome.storage.local.set({[A]:{...a,...e}})}async function F(){return(await chrome.storage.local.get(T))[T]??[]}async function I(e){const a=await F(),t=[e,...a].slice(0,nt);await chrome.storage.local.set({[T]:t})}async function rt(){await chrome.storage.local.remove(T)}async function G(e){var a,t;try{const n=await fetch(`https://www.youtube.com/watch?v=${e}`,{headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!n.ok)return null;const s=(await n.text()).match(/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/);if(!s)return null;const o=JSON.parse(s[1]),d=(t=(a=o==null?void 0:o.captions)==null?void 0:a.playerCaptionsTracklistRenderer)==null?void 0:t.captionTracks;if(!d||d.length===0)return null;const r=st(d);if(!r)return null;const c=r.baseUrl+"&fmt=json3",u=await fetch(c);return u.ok?{segments:((await u.json()).events??[]).filter(h=>h.segs&&h.tStartMs!==void 0).map(h=>({text:(h.segs??[]).map(m=>m.utf8??"").join("").replace(/\n/g," ").trim(),start:(h.tStartMs??0)/1e3,duration:(h.dDurationMs??0)/1e3})).filter(h=>h.text.length>0),language:r.languageCode,isAutoGenerated:r.kind==="asr"}:null}catch{return null}}function st(e){const a=[t=>t.languageCode==="ko"&&t.kind!=="asr",t=>t.languageCode.startsWith("en")&&t.kind!=="asr",t=>t.languageCode==="ko",t=>t.languageCode.startsWith("en"),()=>!0];for(const t of a){const n=e.find(t);if(n)return n}return null}function Y(e){return e.map(a=>{const t=Math.floor(a.start/60),n=Math.floor(a.start%60);return`[${`${String(t).padStart(2,"0")}:${String(n).padStart(2,"0")}`}] ${a.text}`}).join(`
`)}const j="https://api.notion.com/v1",B="2022-06-28";async function H(e,a,t){const n=t.replace(/-/g,""),s=await it(n,a)?{database_id:n}:{page_id:n},o=ct(e),d={parent:s,properties:{title:{title:[{text:{content:e.title.slice(0,2e3)}}]}},children:o},r=await fetch(`${j}/pages`,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json","Notion-Version":B},body:JSON.stringify(d)});if(!r.ok){const u=await r.json().catch(()=>({}));throw r.status===403||u.code==="restricted_resource"?new Error(`Notion 접근 권한 없음
저장할 페이지 우측 상단 ··· → 연결 → Integration 선택`):r.status===404?new Error(`Notion 페이지를 찾을 수 없습니다.
설정의 Page ID가 올바른지 확인해주세요.`):new Error(`Notion 저장 오류 (${r.status}): ${u.message??"요청 실패"}`)}const c=await r.json();return c.url??`https://notion.so/${c.id.replace(/-/g,"")}`}async function it(e,a){try{return(await fetch(`${j}/databases/${e}`,{headers:{Authorization:`Bearer ${a}`,"Notion-Version":B}})).ok}catch{return!1}}function E(e,a=2e3){return[{text:{content:e.slice(0,a)}}]}function ct(e){const a=e.result,t=[],n=(l,p)=>({type:`heading_${p}`,[`heading_${p}`]:{rich_text:E(l)}}),i=l=>({type:"paragraph",paragraph:{rich_text:E(l)}}),s=l=>({type:"bulleted_list_item",bulleted_list_item:{rich_text:E(l)}}),o=()=>({type:"divider",divider:{}}),d=e.contentType==="youtube"?"🎬 유튜브":"📄 웹 페이지",r=a.mode==="learn"?"학습 모드":"일반 모드",c=new Date(e.createdAt).toLocaleString("ko-KR"),u="⭐".repeat(a.recommendation.score);if(t.push(i(`${d} | ${r} | ${c}`)),t.push(i(`🔗 ${e.url}`)),t.push(o()),t.push(n("추천도",2)),t.push(i(`${u} (${a.recommendation.score}/5)  ${a.recommendation.reason}`)),t.push(i(`✅ 추천 대상: ${a.recommendation.bestFor}`)),t.push(i(`⏭️ 스킵 대상: ${a.recommendation.skipIf}`)),t.push(o()),a.mode==="learn")t.push(n("핵심 개념",2)),a.coreConcepts.forEach(l=>{t.push(n(l.concept,3)),t.push(i(l.explanation)),l.whyItMatters&&t.push(i(`💡 ${l.whyItMatters}`))}),t.push(o()),t.push(n("배울 점",2)),a.keyTakeaways.forEach(l=>t.push(s(l))),t.push(o()),t.push(n("실제 적용",2)),t.push(i(a.practicalApplication)),t.push(n("배경 지식",2)),t.push(i(a.backgroundContext)),a.furtherLearning&&(t.push(n("더 알아보기",2)),t.push(i(a.furtherLearning)));else{t.push(n("3줄 요약",2)),a.threeLineSummary.forEach(h=>t.push(s(h))),t.push(o()),t.push(n("전체 요약",2));const l=a.fullSummary,p=1900;for(let h=0;h<l.length;h+=p)t.push(i(l.slice(h,h+p)))}return"keyMoments"in a&&a.keyMoments&&a.keyMoments.length>0&&(t.push(o()),t.push(n("주요 타임스탬프",2)),a.keyMoments.forEach(l=>t.push(s(`[${l.timestamp}] ${l.description}`)))),t.slice(0,100)}const lt=2900;function k(e,a=lt){return e.length>a?e.slice(0,a)+"...":e}async function K(e,a){const t=e.result,n="⭐".repeat(t.recommendation.score),i=e.contentType==="youtube"?"🎬":"📄",s=t.mode==="learn"?"학습 모드":"일반 모드",o=[{type:"header",text:{type:"plain_text",text:`${i} ${e.title}`.slice(0,150),emoji:!0}},{type:"section",fields:[{type:"mrkdwn",text:`*모드:* ${s}`},{type:"mrkdwn",text:`*추천도:* ${n} (${t.recommendation.score}/5)`}]},{type:"section",text:{type:"mrkdwn",text:`*추천 이유:* ${t.recommendation.reason}`}},{type:"section",fields:[{type:"mrkdwn",text:`*✅ 추천 대상:* ${t.recommendation.bestFor}`},{type:"mrkdwn",text:`*⏭️ 스킵 대상:* ${t.recommendation.skipIf}`}]}];if("worthWatching"in t.recommendation&&t.recommendation.worthWatching!==void 0){const r=t.recommendation.worthWatching?"🎬 직접 시청 권장":"📄 요약으로 충분",c=t.recommendation.worthWatchingReason?`: ${t.recommendation.worthWatchingReason}`:"";o.push({type:"section",text:{type:"mrkdwn",text:`*${r}*${c}`}})}if("worthFullRead"in t.recommendation&&t.recommendation.worthFullRead!==void 0){const r=t.recommendation.worthFullRead?"📖 전문 읽기 권장":"📄 요약으로 충분",c=t.recommendation.worthFullReadReason?`: ${t.recommendation.worthFullReadReason}`:"";o.push({type:"section",text:{type:"mrkdwn",text:`*${r}*${c}`}})}if(o.push({type:"divider"}),t.mode==="learn"){const r=t.coreConcepts.map(u=>`*${u.concept}*
${u.explanation}`).join(`

`);o.push({type:"section",text:{type:"mrkdwn",text:`*핵심 개념:*
${k(r)}`}});const c=t.keyTakeaways.map(u=>`• ${u}`).join(`
`);o.push({type:"section",text:{type:"mrkdwn",text:`*배울 점:*
${k(c)}`}}),o.push({type:"section",text:{type:"mrkdwn",text:`*실제 적용:*
${k(t.practicalApplication)}`}})}else{const r=t.threeLineSummary.map(c=>`• ${c}`).join(`
`);o.push({type:"section",text:{type:"mrkdwn",text:`*3줄 요약:*
${r}`}}),o.push({type:"divider"}),o.push({type:"section",text:{type:"mrkdwn",text:`*전체 요약:*
${k(t.fullSummary)}`}})}if("keyMoments"in t&&t.keyMoments&&t.keyMoments.length>0){const r=t.keyMoments.map(c=>`• \`[${c.timestamp}]\` ${c.description}`).join(`
`);o.push({type:"divider"}),o.push({type:"section",text:{type:"mrkdwn",text:`*주요 타임스탬프:*
${k(r,1500)}`}})}o.push({type:"actions",elements:[{type:"button",text:{type:"plain_text",text:"원문 보기",emoji:!0},url:e.url,action_id:"view_original"}]});const d=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({blocks:o})});if(!d.ok)throw new Error(`Slack 전송 오류 (${d.status})`)}const _="syl_watch_later",ut=240,dt="https://www.youtube.com/playlist?list=WL",ht=3;async function L(){const e=await chrome.storage.local.get(_),a={...at,...e[_]??{}},t=new Date().toISOString().slice(0,10);return a.dailyResetDate!==t&&(a.dailyRequestCount=0,a.dailyResetDate=t),a}async function V(e){await chrome.storage.local.set({[_]:e})}async function x(){const e=await L();e.dailyRequestCount++,await V(e)}function mt(e){return e.dailyRequestCount<ut}async function pt(){var t;let e=null,a=!1;try{const n=await chrome.tabs.query({url:"*://www.youtube.com/playlist?list=WL*"});if(n.length>0&&n[0].id!=null)e=n[0].id,await chrome.tabs.reload(e),await R(e);else{if(e=(await chrome.tabs.create({url:dt,active:!1})).id??null,a=!0,e==null)return[];await R(e)}for(let i=0;i<ht;i++){const s=await chrome.scripting.executeScript({target:{tabId:e},func:yt}),o=(t=s==null?void 0:s[0])==null?void 0:t.result;if(o&&o.length>0)return o;await ft((i+1)*2e3)}return[]}catch(n){return console.error("[See You Later] Watch Later fetch failed:",n),[]}finally{a&&e!=null&&chrome.tabs.remove(e).catch(()=>{})}}function ft(e){return new Promise(a=>setTimeout(a,e))}function R(e){return new Promise(a=>{const t=setTimeout(()=>{chrome.tabs.onUpdated.removeListener(n),a()},15e3);function n(i,s){i===e&&s.status==="complete"&&(clearTimeout(t),chrome.tabs.onUpdated.removeListener(n),setTimeout(a,3e3))}chrome.tabs.onUpdated.addListener(n)})}function yt(){var i;const e=new Set,a=[];function t(s,o){s&&!e.has(s)&&(e.add(s),a.push({videoId:s,title:o||"제목 없음"}))}try{const s=document.querySelectorAll("ytd-playlist-video-renderer");for(const d of s){const r=d.querySelector('a#video-title, a.yt-simple-endpoint[href*="/watch"]');if(!r)continue;const u=(r.href||r.getAttribute("href")||"").match(/[?&]v=([a-zA-Z0-9_-]{11})/);u&&t(u[1],(r.textContent??"").trim())}if(a.length>0)return a;const o=document.querySelector('#contents, ytd-playlist-video-list-renderer, [id="playlist-items"]');if(o){const d=o.querySelectorAll('a[href*="/watch?v="]');for(const r of d){const u=(r.href||"").match(/[?&]v=([a-zA-Z0-9_-]{11})/);if(u){const l=((i=r.textContent)==null?void 0:i.trim())||r.getAttribute("title")||"";l.length>1&&t(u[1],l)}}}if(a.length>0)return a}catch{}try{const s=window.ytInitialData;if(s&&typeof s=="object"&&n(s),a.length>0)return a}catch{}try{const s=document.querySelectorAll("script");for(const o of s){const d=o.textContent??"";if(!d.includes("ytInitialData"))continue;const r=d.match(/var\s+ytInitialData\s*=\s*(\{.+?\});\s*(?:<\/script>|$)/s);if(r){const c=JSON.parse(r[1]);if(n(c),a.length>0)return a}}}catch{}return a;function n(s){var d;if(!s||typeof s!="object")return;if(Array.isArray(s)){for(const r of s)n(r);return}const o=s;if(o.playlistVideoRenderer){const r=o.playlistVideoRenderer,c=r.videoId;if(c){const u=r.title,l=u==null?void 0:u.runs,p=u==null?void 0:u.simpleText;t(c,((d=l==null?void 0:l[0])==null?void 0:d.text)??p??"제목 없음");return}}for(const r of Object.keys(o))r==="thumbnail"||r==="playerOverlays"||r==="engagementPanels"||n(o[r])}}const wt=["chrome://","chrome-extension://","about:","edge://","devtools://"],gt=["accounts.google.com","chromewebstore.google.com","chrome.google.com"],$="watch-later-sync";chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});chrome.runtime.onMessage.addListener((e,a,t)=>(kt(e,t),!0));chrome.alarms.onAlarm.addListener(e=>{e.name===$&&q({manual:!1}).catch(a=>{console.error("Watch Later sync failed:",a)})});chrome.runtime.onInstalled.addListener(()=>{M()});chrome.runtime.onStartup.addListener(()=>{M()});async function M(){const e=await w();await chrome.alarms.clear($),e.watchLaterEnabled&&chrome.alarms.create($,{periodInMinutes:e.watchLaterInterval})}async function kt(e,a){try{switch(e.type){case"EXTRACT_AND_SUMMARIZE":{const{mode:t}=e.payload,n=await bt(t);a({success:!0,data:n});break}case"SUMMARIZE":{const{content:t,mode:n}=e.payload,i=await J(t,n);a({success:!0,data:i});break}case"GET_SETTINGS":{const t=await w();a({success:!0,data:t});break}case"SAVE_SETTINGS":{const t=e.payload;await ot(t),await M(),a({success:!0});break}case"GET_HISTORY":{const t=await F();a({success:!0,data:t});break}case"CLEAR_HISTORY":{await rt(),a({success:!0});break}case"EXPORT_NOTION":{const{item:t}=e.payload,n=await w();if(!n.notionToken||!n.notionDatabaseId){a({success:!1,error:"Notion 설정이 완료되지 않았습니다."});break}const i=await H(t,n.notionToken,n.notionDatabaseId);a({success:!0,data:{url:i}});break}case"EXPORT_SLACK":{const{item:t}=e.payload,n=await w();if(!n.slackWebhookUrl){a({success:!1,error:"Slack Webhook URL이 설정되지 않았습니다."});break}await K(t,n.slackWebhookUrl),a({success:!0});break}case"SYNC_WATCH_LATER":{q({manual:!0}).then(t=>a({success:!0,data:{count:t}})).catch(t=>a({success:!1,error:t.message}));return}case"GET_WATCH_LATER_STATUS":{const t=await L();a({success:!0,data:t});break}default:a({success:!1,error:"알 수 없는 메시지 타입"})}}catch(t){const n=t instanceof Error?t.message:"알 수 없는 오류가 발생했습니다.";a({success:!1,error:n})}}function Tt(e){if(wt.some(a=>e.startsWith(a)))return!0;try{const a=new URL(e);return gt.includes(a.hostname)}catch{return!0}}async function St(e){try{await chrome.scripting.executeScript({target:{tabId:e},files:["content/extractor.js"]})}catch{}return await new Promise(a=>setTimeout(a,150)),new Promise((a,t)=>{chrome.tabs.sendMessage(e,{type:"EXTRACT_CONTENT"},n=>{if(chrome.runtime.lastError){t(new Error("페이지와 통신할 수 없습니다. 페이지를 새로고침 후 다시 시도해주세요."));return}if(!(n!=null&&n.success)||!n.data){t(new Error((n==null?void 0:n.error)??"페이지 내용을 추출할 수 없습니다."));return}a(n.data)})})}async function bt(e){const t=(await chrome.tabs.query({active:!0,lastFocusedWindow:!0}))[0];if(!(t!=null&&t.id)||!t.url)throw new Error("현재 탭을 찾을 수 없습니다. 웹 페이지를 열고 다시 시도해주세요.");if(Tt(t.url))throw new Error("이 페이지에서는 요약할 수 없습니다. 일반 웹 페이지나 유튜브에서 사용해주세요.");const n=await St(t.id);if(n.type==="webpage"&&!n.text)throw new Error("이 페이지에서 요약할 콘텐츠를 찾을 수 없습니다. 기사나 블로그 같은 텍스트가 있는 페이지에서 사용해주세요.");return J(n,e)}async function J(e,a){const t=await w();if(!t.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다. 설정 탭에서 입력해주세요.");let n=e;if(e.type==="youtube"&&!e.text&&e.videoId){const o=await G(e.videoId);if(o&&o.segments.length>0)n={...e,text:Y(o.segments),hasSubtitles:!0};else{await x();const d=await U(e,a,t.geminiApiKey),r={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:d,createdAt:Date.now()};return await I(r),{result:d,historyItem:r}}}await x();const i=await P(n,a,t.geminiApiKey),s={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:i,createdAt:Date.now()};return await I(s),{result:i,historyItem:s}}async function q(e){const a=await w();if(!a.geminiApiKey)throw new Error("Gemini API 키가 설정되지 않았습니다.");if(!(e!=null&&e.manual)&&!a.watchLaterEnabled)return 0;const t=!!a.slackWebhookUrl,n=!!a.notionToken&&!!a.notionDatabaseId,i=(e!=null&&e.manual||a.watchLaterAutoExport==="slack"||a.watchLaterAutoExport==="both")&&t,s=(e!=null&&e.manual||a.watchLaterAutoExport==="notion"||a.watchLaterAutoExport==="both")&&n,o=await L(),d=await pt();if(d.length===0)throw new Error(`"나중에 볼 동영상" 목록을 가져올 수 없습니다.
YouTube에 로그인되어 있는지 확인하고, YouTube 탭이 열려 있으면 새로고침 후 다시 시도해주세요.`);const r=o.processedVideoIds.length===0?d:d.filter(m=>!o.processedVideoIds.includes(m.videoId));if(r.length===0)return 0;let c=0,u=0,l=0,p=0,h=0;for(const m of r){if(!mt(o))break;try{const f={type:"youtube",title:m.title,text:"",url:`https://www.youtube.com/watch?v=${m.videoId}`,videoId:m.videoId},y=await G(m.videoId);let S;y&&y.segments.length>0?(f.text=Y(y.segments),f.hasSubtitles=!0,S=await P(f,a.defaultMode,a.geminiApiKey)):S=await U(f,a.defaultMode,a.geminiApiKey),await x();const b={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:f.url,title:m.title,contentType:"youtube",mode:a.defaultMode,result:S,createdAt:Date.now()};if(await I(b),i)try{await K(b,a.slackWebhookUrl),u++}catch(g){p++,console.error("[See You Later] Slack export failed:",g)}if(s)try{await H(b,a.notionToken,a.notionDatabaseId),l++}catch(g){h++,console.error("[See You Later] Notion export failed:",g)}o.processedVideoIds.push(m.videoId),c++,await new Promise(g=>setTimeout(g,6500))}catch{continue}}if(o.lastCheckedAt=Date.now(),o.processedVideoIds.length>500&&(o.processedVideoIds=o.processedVideoIds.slice(-500)),await V(o),c>0){const m=[];u>0&&m.push("Slack"),l>0&&m.push("Notion");const f=[];p>0&&f.push(`Slack ${p}건 실패`),h>0&&f.push(`Notion ${h}건 실패`);let y=`${c}개 영상 요약 완료.`;m.length>0?y+=` ${m.join(" + ")}으로 전송됨.`:!i&&!s&&(y+=" 히스토리에 저장됨 (내보내기 대상 없음)."),f.length>0&&(y+=` [${f.join(", ")}]`),chrome.notifications.create({type:"basic",iconUrl:chrome.runtime.getURL("icons/icon-128.png"),title:"See You Later",message:y})}return c}
