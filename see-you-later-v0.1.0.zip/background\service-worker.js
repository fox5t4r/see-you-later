const k=`당신은 콘텐츠 분석 전문가입니다. 사용자가 웹에서 발견한 글이나 영상의 내용을 분석하여, 사용자의 시간을 절약하고 핵심 가치를 전달하는 것이 목표입니다.

규칙:
1. 모든 응답은 한국어로 작성합니다. 단, 고유명사와 기술 용어는 원문 그대로 유지합니다.
2. 반드시 지정된 JSON 형식으로만 응답합니다. JSON 외의 텍스트는 절대 포함하지 않습니다.
3. JSON 키는 영어로, 값은 한국어로 작성합니다.
4. 추천도 점수 기준:
   - 5점: 반드시 읽어야/봐야 함. 실질적 가치가 매우 높음
   - 4점: 추천. 유용한 인사이트가 있음
   - 3점: 보통. 관심 분야라면 볼 만함
   - 2점: 비추천. 시간 대비 가치가 낮음
   - 1점: 스킵 권장. 내용이 빈약하거나 낚시성`,S=`다음 웹 페이지 내용을 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "coreConcepts": [
    {
      "concept": "핵심 개념 이름",
      "explanation": "이 개념이 무엇인지 초보자도 이해할 수 있게 설명",
      "whyItMatters": "왜 이것이 중요한지"
    }
  ],
  "keyTakeaways": [
    "배울 점 1 - 구체적으로 어떻게 적용할 수 있는지 포함",
    "배울 점 2",
    "배울 점 3"
  ],
  "backgroundContext": "이 내용을 더 잘 이해하기 위해 알면 좋은 배경지식",
  "practicalApplication": "실제로 이 지식을 어떻게 활용할 수 있는지",
  "furtherLearning": "더 깊이 알고 싶다면 찾아볼 키워드나 주제",
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵해도 됨",
    "worthFullRead": true,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,T=`다음 유튜브 영상의 자막/트랜스크립트를 분석하여 학습 자료로 재구성해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "learn",
  "videoTitle": "영상 제목 (자막에서 추론)",
  "coreConcepts": [
    {
      "concept": "핵심 개념",
      "explanation": "친절한 설명",
      "timestamp": "MM:SS (해당 내용이 나오는 시점, 없으면 null)"
    }
  ],
  "keyTakeaways": ["배울 점 1", "배울 점 2", "배울 점 3"],
  "backgroundContext": "배경지식",
  "practicalApplication": "실제 활용법",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "이 시점에서 다루는 내용" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,E=`다음 웹 페이지 내용을 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": [
    "핵심 내용 첫 번째 줄",
    "핵심 내용 두 번째 줄",
    "핵심 내용 세 번째 줄"
  ],
  "fullSummary": "전체 내용을 읽지 않아도 맥락을 완전히 이해할 수 있는 상세 요약. 글의 주장, 근거, 결론을 모두 포함하여 3~5 문단으로 작성.",
  "recommendation": {
    "score": 3,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthFullRead": false,
    "worthFullReadReason": "전문을 읽을 가치가 있는/없는 이유"
  }
}

웹 페이지 내용:`,b=`다음 유튜브 영상의 자막/트랜스크립트를 요약해주세요.

반드시 아래 JSON 형식으로만 응답하세요:
{
  "mode": "summary",
  "threeLineSummary": ["첫 번째 줄", "두 번째 줄", "세 번째 줄"],
  "fullSummary": "영상 전체 내용의 상세 요약. 3~5 문단.",
  "keyMoments": [
    { "timestamp": "MM:SS", "description": "주요 포인트" }
  ],
  "recommendation": {
    "score": 4,
    "reason": "추천 이유",
    "bestFor": "이런 사람에게 추천",
    "skipIf": "이런 사람은 스킵",
    "worthWatching": true,
    "worthWatchingReason": "직접 시청할 가치가 있는/없는 이유",
    "summaryIsSufficient": false,
    "summaryIsSufficientReason": "요약만으로 충분한지 여부와 이유"
  }
}

유튜브 자막/트랜스크립트:`,_="https://api.anthropic.com/v1/messages",O="claude-haiku-4-5";function M(e,a){const t=e.text.length>6e4?e.text.slice(0,6e4)+`

[내용이 너무 길어 일부 생략됨]`:e.text;return a==="learn"?`${e.type==="youtube"?T:S}

제목: ${e.title}
URL: ${e.url}

${t}`:`${e.type==="youtube"?b:E}

제목: ${e.title}
URL: ${e.url}

${t}`}async function x(e,a,t){var u,m;const r=M(e,a),o=await fetch(_,{method:"POST",headers:{"Content-Type":"application/json","x-api-key":t,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},body:JSON.stringify({model:O,max_tokens:2048,system:k,messages:[{role:"user",content:r}]})});if(!o.ok){const y=await o.json().catch(()=>({error:{message:"알 수 없는 오류"}}));throw new Error(`Claude API 오류 (${o.status}): ${((u=y.error)==null?void 0:u.message)??"요청 실패"}`)}const s=((m=(await o.json()).content[0])==null?void 0:m.text)??"",i=s.match(/```(?:json)?\s*([\s\S]*?)```/)??null,n=i?i[1]:s;try{return JSON.parse(n.trim())}catch{throw new Error("AI 응답을 파싱할 수 없습니다. 다시 시도해주세요.")}}const $={defaultMode:"summary",anthropicApiKey:"",openaiApiKey:"",backendUrl:"http://localhost:8000",notionToken:"",notionDatabaseId:"",slackWebhookUrl:"",summaryLanguage:"ko"},h="syl_history",d="syl_settings",I=50;async function p(){const e=await chrome.storage.local.get(d);return{...$,...e[d]??{}}}async function N(e){const a=await p();await chrome.storage.local.set({[d]:{...a,...e}})}async function f(){return(await chrome.storage.local.get(h))[h]??[]}async function A(e){const a=await f(),t=[e,...a].slice(0,I);await chrome.storage.local.set({[h]:t})}async function R(){await chrome.storage.local.remove(h)}async function P(e){var a,t;try{const r=await fetch(`https://www.youtube.com/watch?v=${e}`,{headers:{"Accept-Language":"ko-KR,ko;q=0.9,en;q=0.8"}});if(!r.ok)return null;const c=(await r.text()).match(/ytInitialPlayerResponse\s*=\s*({.+?})\s*;/);if(!c)return null;const s=JSON.parse(c[1]),i=(t=(a=s==null?void 0:s.captions)==null?void 0:a.playerCaptionsTracklistRenderer)==null?void 0:t.captionTracks;if(!i||i.length===0)return null;const n=C(i);if(!n)return null;const u=n.baseUrl+"&fmt=json3",m=await fetch(u);return m.ok?{segments:((await m.json()).events??[]).filter(l=>l.segs&&l.tStartMs!==void 0).map(l=>({text:(l.segs??[]).map(g=>g.utf8??"").join("").replace(/\n/g," ").trim(),start:(l.tStartMs??0)/1e3,duration:(l.dDurationMs??0)/1e3})).filter(l=>l.text.length>0),language:n.languageCode,isAutoGenerated:n.kind==="asr"}:null}catch{return null}}function C(e){const a=[t=>t.languageCode==="ko"&&t.kind!=="asr",t=>t.languageCode.startsWith("en")&&t.kind!=="asr",t=>t.languageCode==="ko",t=>t.languageCode.startsWith("en"),()=>!0];for(const t of a){const r=e.find(t);if(r)return r}return null}function L(e){return e.map(a=>{const t=Math.floor(a.start/60),r=Math.floor(a.start%60);return`[${`${String(t).padStart(2,"0")}:${String(r).padStart(2,"0")}`}] ${a.text}`}).join(`
`)}async function U(e,a){const t=await fetch(`${a}/api/transcribe`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({video_id:e})});if(!t.ok){const r=await t.json().catch(()=>({detail:"알 수 없는 오류"}));throw new Error(`Whisper 변환 오류 (${t.status}): ${r.detail??"요청 실패"}`)}return t.json()}const j="https://api.notion.com/v1",v="2022-06-28";async function D(e,a,t){const r=e.result,o=r.mode==="learn",c=W(e),s=await fetch(`${j}/pages`,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json","Notion-Version":v},body:JSON.stringify({parent:{database_id:t},properties:{title:{title:[{text:{content:e.title}}]},URL:{url:e.url},타입:{select:{name:e.contentType==="youtube"?"유튜브":"웹 페이지"}},모드:{select:{name:o?"학습 모드":"일반 모드"}},추천도:{number:r.recommendation.score},저장일:{date:{start:new Date(e.createdAt).toISOString()}}},children:c})});if(!s.ok){const n=await s.json().catch(()=>({message:"알 수 없는 오류"}));throw new Error(`Notion 저장 오류 (${s.status}): ${n.message??"요청 실패"}`)}const i=await s.json();return i.url??`https://notion.so/${i.id}`}function W(e){const a=e.result,t=[],r=(n,u)=>({type:`heading_${u}`,[`heading_${u}`]:{rich_text:[{text:{content:n}}]}}),o=n=>({type:"paragraph",paragraph:{rich_text:[{text:{content:n}}]}}),c=n=>({type:"bulleted_list_item",bulleted_list_item:{rich_text:[{text:{content:n}}]}}),s=()=>({type:"divider",divider:{}});t.push(r("추천도",2));const i="⭐".repeat(a.recommendation.score);return t.push(o(`${i} (${a.recommendation.score}/5)`)),t.push(o(`📌 ${a.recommendation.reason}`)),t.push(o(`✅ 추천 대상: ${a.recommendation.bestFor}`)),t.push(o(`⏭️ 스킵 대상: ${a.recommendation.skipIf}`)),t.push(s()),a.mode==="learn"?(t.push(r("핵심 개념",2)),a.coreConcepts.forEach(n=>{t.push(r(n.concept,3)),t.push(o(n.explanation)),n.whyItMatters&&t.push(o(`💡 ${n.whyItMatters}`))}),t.push(s()),t.push(r("배울 점",2)),a.keyTakeaways.forEach(n=>t.push(c(n))),t.push(s()),t.push(r("배경 지식",2)),t.push(o(a.backgroundContext)),t.push(r("실제 적용",2)),t.push(o(a.practicalApplication)),a.furtherLearning&&(t.push(r("더 알아보기",2)),t.push(o(a.furtherLearning)))):(t.push(r("3줄 요약",2)),a.threeLineSummary.forEach(n=>t.push(c(n))),t.push(s()),t.push(r("전체 요약",2)),t.push(o(a.fullSummary))),"keyMoments"in a&&a.keyMoments&&a.keyMoments.length>0&&(t.push(s()),t.push(r("주요 타임스탬프",2)),a.keyMoments.forEach(n=>t.push(c(`[${n.timestamp}] ${n.description}`)))),t}async function H(e,a){const t=e.result,r="⭐".repeat(t.recommendation.score),o=e.contentType==="youtube"?"🎬":"📄",c=t.mode==="learn"?"학습 모드":"일반 모드";let s="";t.mode==="learn"?s=t.keyTakeaways.map(u=>`• ${u}`).join(`
`):s=t.threeLineSummary.map(u=>`• ${u}`).join(`
`);const i={blocks:[{type:"header",text:{type:"plain_text",text:`${o} ${e.title}`,emoji:!0}},{type:"section",fields:[{type:"mrkdwn",text:`*모드:* ${c}`},{type:"mrkdwn",text:`*추천도:* ${r} (${t.recommendation.score}/5)`}]},{type:"section",text:{type:"mrkdwn",text:`*추천 이유:* ${t.recommendation.reason}`}},{type:"divider"},{type:"section",text:{type:"mrkdwn",text:`*핵심 내용:*
${s}`}},{type:"actions",elements:[{type:"button",text:{type:"plain_text",text:"원문 보기",emoji:!0},url:e.url,action_id:"view_original"}]}]},n=await fetch(a,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(i)});if(!n.ok)throw new Error(`Slack 전송 오류 (${n.status})`)}const F=["chrome://","chrome-extension://","about:","edge://","devtools://"],J=["accounts.google.com","chromewebstore.google.com","chrome.google.com"];chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{});chrome.runtime.onMessage.addListener((e,a,t)=>(B(e,t),!0));async function B(e,a){try{switch(e.type){case"EXTRACT_AND_SUMMARIZE":{const{mode:t}=e.payload,r=await K(t);a({success:!0,data:r});break}case"SUMMARIZE":{const{content:t,mode:r}=e.payload,o=await w(t,r);a({success:!0,data:o});break}case"WHISPER_TRANSCRIBE":{const{videoId:t}=e.payload,r=await p();if(!r.backendUrl){a({success:!1,error:"백엔드 URL이 설정되지 않았습니다."});break}const o=await U(t,r.backendUrl);a({success:!0,data:o});break}case"GET_SETTINGS":{const t=await p();a({success:!0,data:t});break}case"SAVE_SETTINGS":{await N(e.payload),a({success:!0});break}case"GET_HISTORY":{const t=await f();a({success:!0,data:t});break}case"CLEAR_HISTORY":{await R(),a({success:!0});break}case"EXPORT_NOTION":{const{item:t}=e.payload,r=await p();if(!r.notionToken||!r.notionDatabaseId){a({success:!1,error:"Notion 설정이 완료되지 않았습니다."});break}const o=await D(t,r.notionToken,r.notionDatabaseId);a({success:!0,data:{url:o}});break}case"EXPORT_SLACK":{const{item:t}=e.payload,r=await p();if(!r.slackWebhookUrl){a({success:!1,error:"Slack Webhook URL이 설정되지 않았습니다."});break}await H(t,r.slackWebhookUrl),a({success:!0});break}default:a({success:!1,error:"알 수 없는 메시지 타입"})}}catch(t){const r=t instanceof Error?t.message:"알 수 없는 오류가 발생했습니다.";a({success:!1,error:r})}}function G(e){if(F.some(a=>e.startsWith(a)))return!0;try{const a=new URL(e);return J.includes(a.hostname)}catch{return!0}}async function Y(e){try{await chrome.scripting.executeScript({target:{tabId:e},files:["content/extractor.js"]})}catch{}return await new Promise(a=>setTimeout(a,150)),new Promise((a,t)=>{chrome.tabs.sendMessage(e,{type:"EXTRACT_CONTENT"},r=>{if(chrome.runtime.lastError){t(new Error("페이지와 통신할 수 없습니다. 페이지를 새로고침 후 다시 시도해주세요."));return}if(!(r!=null&&r.success)||!r.data){t(new Error((r==null?void 0:r.error)??"페이지 내용을 추출할 수 없습니다."));return}a(r.data)})})}async function K(e){const t=(await chrome.tabs.query({active:!0,lastFocusedWindow:!0}))[0];if(!(t!=null&&t.id)||!t.url)throw new Error("현재 탭을 찾을 수 없습니다. 웹 페이지를 열고 다시 시도해주세요.");if(G(t.url))throw new Error("이 페이지에서는 요약할 수 없습니다. 일반 웹 페이지나 유튜브에서 사용해주세요.");const r=await Y(t.id);if(r.type==="webpage"&&!r.text)throw new Error("이 페이지에서 요약할 콘텐츠를 찾을 수 없습니다. 기사나 블로그 같은 텍스트가 있는 페이지에서 사용해주세요.");return w(r,e)}async function w(e,a){const t=await p();if(!t.anthropicApiKey)throw new Error("Anthropic API 키가 설정되지 않았습니다. 설정 탭에서 입력해주세요.");let r=e;if(e.type==="youtube"&&!e.text&&e.videoId){const s=await P(e.videoId);if(s&&s.segments.length>0)r={...e,text:L(s.segments),hasSubtitles:!0};else return{needsWhisper:!0,videoId:e.videoId}}const o=await x(r,a,t.anthropicApiKey),c={id:`${Date.now()}-${Math.random().toString(36).slice(2)}`,url:e.url,title:e.title,contentType:e.type,mode:a,result:o,createdAt:Date.now()};return await A(c),{result:o,historyItem:c}}
